import random

# Damos el numero a adivinar este se dara de manera aleatoria con un rango con diferentes
# niveles de dificultad


def play_game():
    print("Bienvenido al ")
    intentos = 0
    puntaje = 0
    print("ahora el puntaje es: ", puntaje)
    print("Tu numero a sido generado mucha suerte!")
    beginner = random.randint(1, 10)
    while True:
        intentos += 1
        print("ahora el puntaje es: ", puntaje)
        respuesta = int(input("Escoge tu numero: "))
        if respuesta == beginner:
            print("Felicidades el numero ", respuesta, " fue la correcta")
            print("Tu puntaje maximo de intentos fue: ", intentos)
            opcion = input("Would you like to play again? (Enter Yes/No): ")
            if opcion == "yes":
                if intentos < puntaje:
                    print("The current high score is: ", intentos)
                    beginner = random.randint(1, 10)
                    puntaje = intentos
                    intentos = 0
                    print("ahora el puntaje es: ", puntaje)
                    print("ahora los intentos son es: ", intentos)
                    print("Tu nuevo numero ha sido generado")
                else:
                    print("The current high score is: ", puntaje)
                    beginner = random.randint(1, 10)
                    puntaje = intentos
                    intentos = 0
                    print("ahora el puntaje es: ", puntaje)
                    print("ahora los intentos son es: ", intentos)
                    print("Tu nuevo numero ha sido generado")
            else:
                break
        elif respuesta < beginner:
            print(respuesta, "Es muy bajo, prueba un numero mas alto")
        else:
            print(respuesta, "Es muy alto, prueba un numero menor")


play_game()
