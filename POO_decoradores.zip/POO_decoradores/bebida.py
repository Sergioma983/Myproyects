class NotificationStrategy:
    def message(self, title, content):
        pass


class SMSNotification(NotificationStrategy):
    def message(self, title, content):
        return f"Tienes un nuevo mensaje de SMS {title}\n{content}"


class EmailNotification(NotificationStrategy):
    def message(self, title, content):
        return f"Tienes un nuevo mensaje de Email {title}\n{content}"


class InstagramNotification(NotificationStrategy):
    def message(self, title, content):
        return f"Tienes un nuevo mensaje de Instagram {title}\n{content}"


class WhatsappNotification(NotificationStrategy):
    def message(self, title, content):
        return f"Tienes un nuevo mensaje de Whatsapp {title}\n{content}"


class FacebookNotification(NotificationStrategy):
    def message(self, title, content):
        return f"Tienes un nuevo mensaje de Facebook {title}\n{content}"


class Sound:
    def __init__(self, strategy):
        self.strategy = strategy

    def set_strategy(self, strategy):
        self.strategy = strategy

    def message(self, title, content):
        return self.strategy.message(title, content)


# Creamos instancias de las diferenres estrategias de viaje
message1 = SMSNotification()
message2 = EmailNotification()
message3 = InstagramNotification()
message4 = WhatsappNotification()
message5 = FacebookNotification()

# Creamos una instancia del viajero con la estrategia de ir caminando
messaging = Sound(message1)
title, content = 'Calificación', 'Tu calificación es de 10'
# Utilizamos la instancia del viajero para recorrer diferentes distrancias
print(messaging.message(title, content))
messaging.set_strategy(message2)
print(messaging.message(title, content))
messaging.set_strategy(message3)
print(messaging.message(title, content))
messaging.set_strategy(message4)
print(messaging.message(title, content))
messaging.set_strategy(message5)
print(messaging.message(title, content))
