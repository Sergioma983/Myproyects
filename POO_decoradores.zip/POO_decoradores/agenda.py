import csv


class Contacto:
    def __init__(self, nombre, telefono, correo):
        self.nombre = nombre
        self.telefono = telefono
        self.correo = correo


class Agenda:
    def __init__(self, filename):
        self.filename = filename
        self.contactos = []

    def agregar_contacto(self, contacto):
        self.contactos.append(contacto)

    def eliminar_contacto(self, nombre):
        for contacto in self.contactos:
            if contacto.nombre == nombre:
                self.contactos.remove(contacto)
                break

    def buscar_contacto(self, nombre):
        for contacto in self.contactos:
            if contacto.nombre == nombre:
                return contacto
        return None

    def mostrar_contactos(self):
        for contacto in self.contactos:
            print(
                f"Nombre: {contacto.nombre}\nTeléfono: {contacto.telefono}\nCorreo: {contacto.correo}\n")

    def guardar_contactos(self):
        with open(self.filename, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Nombre", "Teléfono", "Correo"])
            for contacto in self.contactos:
                writer.writerow(
                    [contacto.nombre, contacto.telefono, contacto.correo])

    def cargar_contactos(self):
        with open(self.filename, 'r') as file:
            reader = csv.reader(file)
            next(reader)  # Saltar la primera fila (encabezados)
            for row in reader:
                contacto = Contacto(row[0], row[1], row[2])
                self.contactos.append(contacto)


# Ejemplo de uso
agenda = Agenda('agenda.csv')
agenda.cargar_contactos()

contacto1 = Contacto('Nancy', '98765', 'nancy@mail.com')
agenda.agregar_contacto(contacto1)

contacto2 = Contacto('Oscar', '18273', 'oscar@mail.com')
agenda.agregar_contacto(contacto2)

# agenda.eliminar_contacto('Juan')

contacto3 = Contacto('Brandon', '6573829', 'brandon@mail.com')
agenda.agregar_contacto(contacto3)

contacto = agenda.buscar_contacto('Sergio')
if contacto:
    print(
        f"Contacto encontrado: {contacto.nombre}\nTeléfono: {contacto.telefono}\nCorreo: {contacto.correo}\n")
else:
    print("Contacto no encontrado.")

agenda.mostrar_contactos()

agenda.guardar_contactos()
