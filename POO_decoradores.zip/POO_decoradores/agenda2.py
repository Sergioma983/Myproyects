import csv
import os.path
import time


class Contacto:
    def __init__(self, nombre, telefono, correo):
        self.nombre = nombre
        self.telefono = telefono
        self.correo = correo


class Agenda:
    def __init__(self, filename):
        self.filename = filename
        self.contactos = []
        self.cargar_contactos()

    def agregar_contacto(self):
        os.system('cls')
        nombre = input("Ingrese el nombre del nuevo contacto: ")
        telefono = input("Ingrese el teléfono del nuevo contacto: ")
        correo = input("Ingrese el correo del nuevo contacto: ")
        contacto = Contacto(nombre, telefono, correo)
        self.contactos.append(contacto)
        self.guardar_contactos()
        print("Tu contacto ha sido guardado con exito")

    def eliminar_contacto(self):
        os.system('cls')
        nombre = input("Ingrese el nombre del contacto que desea eliminar: ")
        for contacto in self.contactos:
            if contacto.nombre == nombre:
                self.contactos.remove(contacto)
                break
        self.guardar_contactos()
        print("Tu contacto ha sido eliminado con exito")

    def buscar_contacto(self):
        os.system('cls')
        nombre = input("Ingrese el nombre del contacto que desea buscar: ")
        for contacto in self.contactos:
            if contacto.nombre == nombre:
                print(
                    f"Nombre: {contacto.nombre}\nTeléfono: {contacto.telefono}\nCorreo: {contacto.correo}\n")
                break
        else:
            print(f"No se encontró ningún contacto con el nombre {nombre}")

    def mostrar_contactos(self):
        os.system('cls')
        for contacto in self.contactos:
            print(
                "----------------------------------------------------------------------------------------")
            print(
                f"Nombre: {contacto.nombre}\nTeléfono: {contacto.telefono}\nCorreo: {contacto.correo}\n")

    def guardar_contactos(self):
        with open(self.filename, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Nombre", "Teléfono", "Correo"])
            for contacto in self.contactos:
                writer.writerow(
                    [contacto.nombre, contacto.telefono, contacto.correo])

    def cargar_contactos(self):
        with open(self.filename, 'r') as file:
            reader = csv.reader(file)
            next(reader)
            for row in reader:
                contacto = Contacto(row[0], row[1], row[2])
                self.contactos.append(contacto)


def crear_archivo(filename):
    with open(filename, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Nombre", "Teléfono", "Correo"])


def preguntar_regresar():
    while True:
        respuesta = input("¿Regresar al menú principal? (s/n): ")
        if respuesta.lower() == "s":
            return True
        elif respuesta.lower() == "n":
            return False
        else:
            print("Respuesta inválida. Intente de nuevo.")


filename = "contactos.csv"
if not os.path.isfile(filename):
    crear_archivo(filename)
agenda = Agenda(filename)

while True:
    print("Bienvenido a su agenda personal")
    print("Seleccione una opción:")
    print("1. Agregar un contacto")
    print("2. Eliminar un contacto")
    print("3. Buscar un contacto")
    print("4. Mostrar todos los contactos")
    print("5. Salir")
    opcion = input("Opción: ")

    if opcion == "1":
        agenda.agregar_contacto()
        if preguntar_regresar():
            os.system('cls')
            continue
        else:
            print("Pasa buen día")
            break
    elif opcion == "2":
        agenda.eliminar_contacto()
        if preguntar_regresar():
            os.system('cls')
            continue
        else:
            print("Pasa buen día")
            break
    elif opcion == "3":
        agenda.buscar_contacto()
        if preguntar_regresar():
            os.system('cls')
            continue
        else:
            print("Pasa buen día")
            break
    elif opcion == "4":
        agenda.mostrar_contactos()
        if preguntar_regresar():
            os.system('cls')
            continue
        else:
            print("Pasa buen día")
            break
    elif opcion == "5":
        print("Pasa buen día")
        break
    else:
        print("Opción inválida. Intente de nuevo.")
