class Product:
    def __init__(self, name, price, popularity, available):
        self.name = name
        self.price = price
        self.popularity = popularity
        self.available = available

    def __repr__(self):
        return f"{self.name}: {self.price} ({self.popularity}) {'available' if self.available else 'unavailable'}"


class ProductStrategy:
    def classify(self, products):
        pass


class PriceStrategy(ProductStrategy):
    def classify(self, products):
        return sorted(products, key=lambda p: p.price)


class PopularityStrategy(ProductStrategy):
    def classify(self, products):
        return sorted(products, key=lambda p: p.popularity, reverse=True)


class AvailabilityStrategy(ProductStrategy):
    def classify(self, products):
        return [p for p in products if p.available] + [p for p in products if not p.available]


class ProductClassifier:
    def __init__(self, strategy):
        self.strategy = strategy

    def set_strategy(self, strategy):
        self.strategy = strategy

    def classify(self, products):
        return self.strategy.classify(products)


# Creamos una lista de productos
products = [
    Product("producto 1", 100, 10, True),
    Product("producto 2", 50, 8, True),
    Product("producto 3", 200, 5, False),
    Product("producto 4", 80, 9, True),
    Product("producto 5", 150, 6, False),
]

# Creamos una instancia del clasificador con la estrategia de clasificación por precio
classifier = ProductClassifier(PriceStrategy())

# Clasificamos los productos según la estrategia actual
print(classifier.classify(products))

# Cambiamos la estrategia de clasificación a popularidad y clasificamos de nuevo
classifier.set_strategy(PopularityStrategy())
print(classifier.classify(products))

# Cambiamos la estrategia de clasificación a disponibilidad y clasificamos de nuevo
classifier.set_strategy(AvailabilityStrategy())
print(classifier.classify(products))
