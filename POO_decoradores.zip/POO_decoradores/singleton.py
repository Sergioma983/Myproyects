def singleton(cls):

    instances = dict()

    def wrap(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)

        return instances[cls]
    return wrap


@singleton
class User(object):
    def __init__(self, username, description):
        self.username = username
        self.description = description


class Database:
    __instance = None

    def __init__(self):
        if Database.__instance is not None:
            raise Exception(
                "La clase es un Singleton y no se puede instanciar nuevamente")
        else:
            Database.__instance = self
            self.host = "localhost"
            self.port = 5432
            self.user = "root"
            self.password = "password"
            self.database = "mydatabase"


@staticmethod
def getInstance():
    if Database.__instance is None:
        Database()
    return Database.__instance


if __name__ == '__main__':
    db = Database.getInstance()
    print(vars(db))
    user2 = User('Facilito', 'Cody')
    user1 = User('Cody', 'Facilito')

    print(user1.username, user1.description)
    print(user2.username, user2.description)
    print(user1 is user2)
