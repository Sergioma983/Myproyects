class ListStrategy:
    def sort(self, lista):
        pass


class BubbleStrategy(ListStrategy):
    def sort(self, lista):
        n = len(lista)
        for i in range(n):
            for j in range(n - i - 1):
                if lista[j] > lista[j + 1]:
                    lista[j], lista[j + 1] = lista[j + 1], lista[j]
        return lista


class SelectionStrategy(ListStrategy):
    def sort(self, lista):
        n = len(lista)
        for i in range(n):
            min_idx = i
            for j in range(i+1, n):
                if lista[j] < lista[min_idx]:
                    min_idx = j
            lista[i], lista[min_idx] = lista[min_idx], lista[i]
        return lista


class InsercionStrategy(ListStrategy):
    def sort(self, lista):
        n = len(lista)
        for i in range(1, n):
            actual = lista[i]
            j = i - 1

            while j >= 0 and lista[j] > actual:
                lista[j + 1] = lista[j]
                j -= 1
            lista[j + 1] = actual

        return lista


class ShellStrategy(ListStrategy):
    def sort(self, lista):
        n = len(lista)
        gap = n // 2

        while gap > 0:
            for i in range(gap, n):
                temp = lista[i]
                j = i
                while j >= gap and lista[j-gap] > temp:
                    lista[j] = lista[j-gap]
                    j -= gap
                lista[j] = temp
            gap //= 2

        return lista


class Method:
    def __init__(self, strategy):
        self.strategy = strategy

    def set_strategy(self, strategy):
        self.strategy = strategy

    def sort(self, lista):
        return self.strategy.sort(lista)


# Creamos instancias de las diferenres estrategias de viaje
bubble_sort = BubbleStrategy()
selection_sort = SelectionStrategy()
insercion_sort = InsercionStrategy()
shell_sort = ShellStrategy()

# Creamos una instancia del viajero con la estrategia de ir caminando
sort_method = Method(bubble_sort)

# Utilizamos la instancia del viajero para recorrer diferentes distrancias
lista1 = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5,
          8, 9, 8, 7, 7, 54, 55, 48, 11, 22, 3, 32]
print(sort_method.sort(lista1))
sort_method.set_strategy(selection_sort)
lista2 = [35, 5, 8, 9, 89, 7, 55, 8, 84, 5, 4,
          88, 45, 454, 8, 454, 8, 814, 548, 2, 8, 4]
print(sort_method.sort(lista2))
sort_method.set_strategy(insercion_sort)
print(sort_method.sort(lista1))
sort_method.set_strategy(shell_sort)
print(sort_method.sort(lista2))
