class VodkaStrategy:
    def coctel(self, soda):
        pass


class ScrewdriverStrategy(VodkaStrategy):
    def coctel(self, soda):
        if soda == 'naranja':
            return f"Tu bebida es Screwdriver"
        else:
            return f"La bebida Screwdriver necesita naranja"


class SeabreezeStrategy(VodkaStrategy):
    def coctel(self, soda):
        if soda == 'toronja y arandano':
            return f"Tu bebida es Seabreeze"
        else:
            return f"La bebida Seabreeze necesita toronja y arandano"


class LemonStrategy(VodkaStrategy):
    def coctel(self, soda):
        if soda == 'Limon':
            return f"Tu bebida es Lemon"
        else:
            return f"La bebida Lemon necesita limon"


class Drink:
    def _init_(self, strategy):
        self.strategy = strategy

    def set_strategy(self, strategy):
        self.strategy = strategy

    def coctel(self, soda):
        return self.strategy.coctel(soda)


# Creamos instancias de las diferenres estrategias de viaje
drink1 = ScrewdriverStrategy()
drink2 = SeabreezeStrategy()
drink3 = LemonStrategy()

# Creamos una instancia del viajero con la estrategia de ir caminando
drinking = Drink(drink1)

# Utilizamos la instancia del viajero para recorrer diferentes distrancias
print(drinking.coctel('naranja'))
print(drinking.coctel('uva'))
drinking.set_strategy(drink2)
print(drinking.coctel('toronja y arandano'))
print(drinking.coctel('naranja'))
drinking.set_strategy(drink3)
print(drinking.coctel('Limon'))
print(drinking.coctel('uva'))
