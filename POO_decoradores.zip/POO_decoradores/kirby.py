class Kirby:
    def __init__(self, poder):
        self.poder = poder


class Mario:
    def __init__(self):
        self.poder1 = "Mapache"
        self.poder2 = "Fuego"
        self.poder3 = "Lanzar tortuga"


class PowerUpAdapter(Kirby):
    def __init__(self, mario):
        super().__init__(None)
        self.mario = mario

    def copiar_poder(self, poder):
        if poder == "Mapache":
            self.poder = self.mario.poder1
            print("El poder", poder, "ha sido copiado.")
        elif poder == "Fuego":
            self.poder = self.mario.poder2
            print("El poder", poder, "ha sido copiado.")
        elif poder == "Lanzar tortuga":
            self.poder = self.mario.poder3
            print("El poder", poder, "ha sido copiado.")
        else:
            print("El poder", poder, "no puede copiarse.")


mario = Mario()
adapter = PowerUpAdapter(mario)
adapter.copiar_poder("Fuego")
adapter.copiar_poder("Mapache")
adapter.copiar_poder("Lanzar tortuga")
adapter.copiar_poder("Hielo")
adapter.copiar_poder("Piedra")
