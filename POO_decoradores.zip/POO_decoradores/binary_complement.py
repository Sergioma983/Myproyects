from math import floor
# programa para convertir un numero decimal a binario
# dando un numero de bits deseado
# ademas el complemento de dos de este

# iniciamos preguntando el numero a convertir
# y el numero de bits


def binary_complement():
    # esta funcion es la principal del programa, mediante un while
    # verifica que la entrada solo sea un numero entero, ni, flotantes, ni cadenas.
    # esto gracias a una funcion de python la cual es, la siguiente
    # isdigit() en una cadena de caracteres para determinar si solo contiene caracteres numéricos
    while True:
        decimal_number = input("Ingresa tu numero para convertirlo: ")
        if decimal_number.isdigit():
            checking = int(decimal_number)
            break
        else:
            print(
                "\n", "Ops, aun no puedo convertir letras o numeros decimales a binario. Intenta otra vez", "\n")
    print("el numero ingresado es: ", decimal_number)


def num_binary(numero):
    binario = ""
    while numero > 0:
        residuo = numero % 2
        binario = str(residuo) + binario
        decimal = decimal // 2
    print("El numero binario de ", decimal, "es: ", binario)


if __name__ == '__main__':
    # binary_complement()
    num_binary(14)
