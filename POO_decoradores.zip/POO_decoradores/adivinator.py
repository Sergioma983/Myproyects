import random

best_score = 0
print("Welcome to adivinator")
name_player = input(("What is your name?: "))
print("hi", name_player, "get ready to play")
while True:
    num_random = random.randint(1, 10)
    print("Your number has been generated between 1 and 10 a lot of luck!")
    attempts = 0
    if best_score == 0:
        print("There is currently no high score, choose wisely")
    else:
        print("Your maximum score is:", best_score)
    while True:
        answer = int(input("Choose your number: "))
        attempts += 1
        if answer == num_random:
            print("Congratulations on the number", answer, "was correct.")
            print("It took you", attempts, "attempts")
            break
        elif answer < num_random:
            print("It's very low, try a higher number.")
        else:
            print("It's very high, try a smaller number.")
    if best_score == 0 or attempts < best_score:
        best_score = attempts
    new_play = input("Would you like to play again? (Enter y/n): ")
    if new_play.lower() != "y":
        print("Thanks for playing, come back soon")
        break
