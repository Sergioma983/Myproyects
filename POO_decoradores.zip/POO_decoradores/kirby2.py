class Kirby:
    def copy_ability(self, ability):
        adapter = PowerUpAdapter()
        adapter.copy_ability(ability)


class Mario:
    def use_power_up(self, power_up):
        print("Mario has used the {} power-up!".format(power_up))


class PowerUpAdapter:
    def __init__(self):
        self.power_ups = {
            "fuego": "Flower",
            "lanzar tortuga": "Shell",
            "mapache": "Leaf"
        }

    def copy_ability(self, ability):
        if ability in self.power_ups:
            mario = Mario()
            mario.use_power_up(self.power_ups[ability])
        else:
            print("Error: {} no es una habilidad válida para copiar".format(ability))


# Crear instancias de los objetos
kirby = Kirby()

# Copiar la habilidad de fuego de Mario a Kirby
kirby.copy_ability("fuego")

# Intentar copiar la habilidad de espada de Mario a Kirby
kirby.copy_ability("espada")
