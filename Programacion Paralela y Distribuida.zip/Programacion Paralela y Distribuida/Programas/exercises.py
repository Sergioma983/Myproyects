
while True:
    print("\n")
    numero = int(input("Ingresa un numero: "))
    if numero % 2 == 0:
        print('El número', numero, 'es par.')
    else:
        print('El número', numero, 'es impar.')
    repetir = input("¿Quieres verificar otro numero? si / no: ")
    if repetir == "no":
        break
print("\n")
print("Vuelve pronto")
