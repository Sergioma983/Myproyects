import matplotlib.pyplot as plt
import time
import time_experiments as profile


def len_collatz(n):
    len = 1
    while n != 1:
        if n % 2 == 0:
            n /= 2
        else:
            n = (n*3)+1
        len += 1
    return len


def profile_collatz(toLimit):
    for a in range(2, toLimit):
        len = len_collatz(a)
    return len


def main():
    test = profile_collatz(100000)
    print(test)


main()
