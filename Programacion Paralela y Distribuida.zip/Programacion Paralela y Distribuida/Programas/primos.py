def is_relative_prime(a, b):
    pass


def is_relative_prime(a):
    if a < 1:
        return False
    for d in range(2, a):
        if a % d == 0:
            return False
    return True


print("-"*30)
print("n", "|".center(10), "Is_prime_number".center(10))
print("-"*30)

for a in range(1, 101):
    if is_relative_prime(a):
        print("{0}".format(a).center(5), "|", "True".center(15))
    else:
        print("{0}".format(a).center(5), "|", "False".center(15))

print("-"*30)
