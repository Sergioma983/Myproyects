while True:
    print("\n")
    mes = int(
        input("Ingresa el numero de mes que deseas saber los días que tiene: "))
    if mes <= 0:
        print("Ingresa el numero de mes correcto")
    if mes in [4, 6, 9, 11]:
        print("El mes %d tiene 30 dias." % mes)
    if mes == 2:
        año = int(
            input("Ingresa el año donde se encuentra el mes, que deseas saber los días: "))
        if año % 4 != 0:
            print("El mes %d tiene 28 dias." % mes)
        elif año % 4 == 0 and año % 100 != 0:
            print("El mes %d tiene 29 dias por ser bisiesto." % mes)
    if mes in [1, 3, 5, 7, 8, 10, 12]:
        print("El mes %d tiene 31 dias." % mes)
    if mes > 12:
        print("Ingresa el numero de mes correcto")
    repetir = input("¿Quieres verificar otro mes? si / no: ")
    if repetir == "no":
        break
print("\n")
print("Vuelve pronto")
