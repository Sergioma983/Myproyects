def relative_prime(x, y):
    a = min(x, y)
    b = max(x, y)
    div = 2
    while (div <= a):
        if((a % div == 0) and (b % div == 0)):
            return False
        div += 1
    return True

def imp_tabla():
    print("    2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |")
    print("-"*45)
    for i in range(2, 12):
        print(i, end="")
        for j in range(2, 12):
            if relative_prime(i, j) == True:
                print(" |*", end=" ")
            else:
                print(" | ", end=" ")
        print(" ", end=" |")
        print('')
        print("-"*45)

if __name__ == "__main__":
    imp_tabla()
