import random
import math
import time
import matplotlib.pyplot as plt


def estimate_pi(num_points):
    """

    """
    num_inside = 0

    for _ in range(num_points):
        x = random.random()
        y = random.random()
        if x**2 + y**2 <= 1.0:
            num_inside += 1

    aproximate_pi = 4*num_inside / num_points

    return aproximate_pi


def main():
    print("\n")
    print("-"*50)
    print("Aproximate Pi - Montecarlo".center(50))
    print("\n")
    print("-"*50)

    numeros = range(int(1e5), int(1e6), 100000)

    for i in numeros:
        tic = time.time()
        value = estimate_pi(i)
        toc = time.time()
        print("El valor aproximado de PI es:", value, "usando ", i, " puntos")
        print("EL valor real de PI es: ", math.pi)
        print("error  de aproximacion:", abs((value - math.pi)/math.pi))
        print("estimate_pi took time: ", toc-tic)
        print("-"*50)


if __name__ == "__main__":
    main()
