while True:
    print("\n")
    lados = int(input("Ingresa el numero de lados de tu figura: "))
    if lados == 3:
        print("Tu figura es un triangulo")
    elif lados == 4:
        figura = input("¿Tu figura de 4 lados todos son iguales? si / no: ")
        if figura == "no":
            print("Tu figura es un Rectangulo")
        else:
            print("Tu figura es un cuadrado")
    elif lados == 5:
        print("Tu figura es un pentagono")
    elif lados == 6:
        print("Tu figura es un hexagono")
    elif lados == 7:
        print("Tu figura es un heptagono")
    elif lados == 8:
        print("Tu figura es un octagono")
    elif lados == 9:
        print("Tu figura es un enagono")
    elif lados == 10:
        print("Tu figura es un decagono")
    elif lados > 10:
        print("Solo se aceptan figuras de no mas de 10 lados")
    repetir = input("¿Quieres verificar otra figura? si / no: ")
    if repetir == "no":
        break
print("\n")
print("Vuelve pronto")
