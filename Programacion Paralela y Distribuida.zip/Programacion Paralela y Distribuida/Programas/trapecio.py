# Integración: Regla de los trapecios
# Usando una función fx()
import numpy as np
import time_experiments as profile
import matplotlib.pyplot as plt

# INGRESO


def fx(x): return 1.25*np.sin(x)+3


def trapecio(nu):
    # intervalo de integración
    a = 1
    b = 9
    tramos = nu

    # PROCEDIMIENTO
    # Regla del Trapecio
    # Usando tramos equidistantes en intervalo
    h = (b-a)/tramos
    xi = a
    suma = fx(xi)
    for i in range(0, tramos-1, 1):
        xi = xi + h
        suma = suma + 2*fx(xi)
    suma = suma + fx(b)
    area = h*(suma/2)

    return area


if __name__ == "__main__":
    size = range(int(1e6), int(1e7), 1000000)
    profile.run_experiments(trapecio, size,
                            10, "Trapecio")
