print("Primer numero: ")
primer_numero = int(input())
print("Segundo numero: ")
segundo_numero = int(input())
suma = primer_numero + segundo_numero
print("Suma: " + str(suma))
