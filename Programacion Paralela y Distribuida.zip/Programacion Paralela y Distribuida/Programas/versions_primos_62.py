def is_relative_prime_v1(x, y):
    """[summary]
        Dos numeros x, y son primos relativos el unico divisor comun es el 1
    Args:
        x ([int]): [description]
        y ([int]): [description]
    """
    m = min(x, y) + 1

    for d in range(2, m):
        if x % d == 0 and y % d == 0:
            return False
    return True


def is_relative_prime_v2(a, b):
    tmp = 0
    while b != 0:
        if a < b:
            tmp = a
            a = b
            b = tmp
        tmp = b
        b = a % b
        a = tmp
    if a == 1:
        return True
    else:
        return False


def is_relative_prime_v3(i, j):
    a = min(i, j)
    b = max(i, j)
    div = 2
    while (div <= a):
        if((a % div == 0) and (b % div == 0)):
            return False
        div += 1

    return True


def is_relative_prime_v4(i, j) -> int:
    """
        Esta función recursiva valida si dos numeros
        son relativamente primos mediante la recursividad
    Args:

        i ([int]): [numero 1]
        j ([int]): [numero 2]

    Returns:
        int: [retorna 1 si son relativamente primos, retorna otro numero si no lo son] 
    """

    if j == 0:
        if i == 1:
            return True
        else:
            return False
    elif i < j:
        return is_relative_prime_v4(j, i)

    return is_relative_prime_v4(j, i % j)
