import matplotlib.pyplot as plt
import time
import versions_primos_62 as vp


def is_relative_prime(x, y):
    """[summary]
        Dos numeros x, y son primos relativos el unico divisor comun es el 1 
    Args:
        x ([int]): [description]
        y ([int]): [description]
    """
    m = min(x, y) + 1

    for d in range(2, m):
        if x % d == 0 and y % d == 0:
            return False
    return True


def main():

    tic = time.time()
    size = 500
    tabla_primos = [[False]*size for _ in range(size)]

    for i in range(2, size):
        for j in range(2, size):
            tabla_primos[i][j] = is_relative_prime(i, j)

    toc = time.time()
    print("table took time: ", toc-tic)
    tic = time.time()
    plt.matshow(tabla_primos)
    plt.show()
    toc = time.time()
    print("plot took time: ", toc-tic)


if __name__ == "__main__":
    main()
