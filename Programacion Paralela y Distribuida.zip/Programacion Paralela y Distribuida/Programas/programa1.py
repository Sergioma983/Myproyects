"""
Calcular  la suma de números intervalos dado s[no , n_1]$,

"""


def sum_in_range(lolim, uplimit):
    """Suma los numeros enteros contenidos en un intervalo
    Args:
        lolim ([int]): limite inferior
        uplimit ([int]): limite superior
    Returns:
        el valor de la suma intervala
    """
    sum_value = 0
    uplimit += 1

    for value in range(lolim, uplimit):
        sum_value += value

    return sum_value


def main():
    print("\n")
    print("-"*30)
    print(" Test suma")

    lolimit = 0
    uplimit = 100
    sum = sum_in_range(lolimit, uplimit)
    print("sum from {0} to {1}: {2}".format(lolimit, uplimit, sum))
    print("\n")


if __name__ == "__main__":
    main()
