# Funcion para calcular el tiempo de ejecucion y ploteo de ciertos experimentos

import matplotlib.pyplot as plt
import time


def run_experiments(function_profile, argumentos, num_experiments,
                    title="Time process", xlabel="Limits", ylabel="Time process (s)"):
    """[summary]
    ejecuta num_experiments veces la funcion function_profile y
    toma el tiempo de ejecucion para cada limit en limits pasado como
    argumento a la function_profile.

    Se generar una tabla de tiempos de ejecucion
    Args:
        function_profile ([funcion]): la funcion a perfilar
        argumentos (lista): lista de argumentos a pasar a la funcion
        num_experiments ([int]): el numero de veces que se ejecuta la
            funcion para cada argumento dado

    Return:
        La tabla de tiempos de ejecucion
    """
    table_time_results = [
        [0.0]*num_experiments for _ in range(len(argumentos))]

    idx = 0
    for arg in argumentos:
        print(f"running experiments for arg {arg}")
        for run in range(num_experiments):
            print(f"\trunning experiment # {run} ")
            tic = time.time()
            function_profile(arg)
            toc = time.time()
            table_time_results[idx][run] = toc-tic
        idx += 1

    for i in range(len(argumentos)):
        plt.scatter([argumentos[i]]*len(table_time_results[i]),
                    table_time_results[i])

    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.show()

    return table_time_results
