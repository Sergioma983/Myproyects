
print("\n")
print("Ejercicio 3")
print("\n")
print("Ingresa el ancho de la habitacion: ")
ancho = float(input())
print("Ingresa el largo de la habitacion: ")
largo = float(input())

print("El area de la habitación es: ", ancho*largo)
print("\n")
print("Ejercicio 5")
print("\n")

print("Ingresa el numero de botellas menor a 1 litro: ")
num_botellas_chicas = int(input())
print("Ingresa el numero de botellas mayor a un 1 litro: ")
num_botellas_grandes = int(input())
importe = num_botellas_chicas * 0.10 + num_botellas_grandes * 0.25
print(f"El importe total es de: ${importe:.2f}")
print("\n")
print("Ejercicio 6")
print("\n")
print("¿Cual es el costo de la comida?: ")
comida = float(input())
tax = comida*0.16
tip = comida*0.18
total = comida+tax+tip

print("El importe total es: ")
print(f"Precio Comida:".center(10), f"${comida:.2f}".center(12))
print(f"tax (16%):".center(10), f"${tax:.2f}".center(20))
print(f"tip (18%):".center(10), f"${tip:.2f}".center(20))
print("-"*20)
print(f"Grand TOTAL:".center(10), f"${total:.2f}".center(15))
