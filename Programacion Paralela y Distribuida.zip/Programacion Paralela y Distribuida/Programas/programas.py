import matplotlib.pyplot as plt
import time


def sum_in_range(lolimit, uplimit):
    """Suma los numeros enteros contenidos en un intervalo, incluyendo los extremos
        Formula de Gauss


    Args:
        lolim ([int]): [Limite inferior que define el intervalo]
        uplimit ([int]): [Limite superior que define el intervalo]
    Returns:
        El valor de la suma del intervalo
    """

    sum_value = 0
    uplimit += 1
    for value in range(lolimit, uplimit):
        sum_value += value
    return sum_value


def time_table_experiments(upper_limits, num_experiments):
    nrow = len(upper_limits)
    time_table = [[0.0]*num_experiments for _ in range(nrow)]

    row_limit = 0
    for limit in upper_limits:
        print(f"run {num_experiments} experiments for limit {limit}...")
        for experiment in range(num_experiments):
            tic = time.time()
            sum = sum_in_range(0, limit)
            toc = time.time()
            time_table[row_limit][experiment] = format(
                round(toc-tic, 6)).center(10)
        row_limit += 1

    return time_table


if __name__ == "__main__":
    upper_limits = range(int(1e6), int(1e8), 9000000)
    time_table = time_table_experiments(upper_limits, 10)

    for i in range(len(upper_limits)):
        plt.scatter([upper_limits[i]]*len(time_table[i]), time_table[i])

    plt.title("Suma números -- time process")
    plt.xlabel('Upper Limits')
    plt.ylabel('Time process (s)')
    plt.show()

    print("-"*156)
    print("lower".center(15) + "|" +
          "time".center(13) + "|" +
          "time".center(13) + "|" +
          "time".center(13) + "|" +
          "time".center(13) + "|" +
          "time".center(13) + "|" +
          "time".center(13) + "|" +
          "time".center(13) + "|" +
          "time".center(13) + "|" +
          "time".center(13) + "|" +
          "time".center(13) + "|")
    print("Limit".center(15) + "|" +
          "exp1".center(13) + "|" +
          "exp2".center(13) + "|" +
          "exp3".center(13) + "|" +
          "exp4".center(13) + "|" +
          "exp5".center(13) + "|" +
          "exp6".center(13) + "|" +
          "exp7".center(13) + "|" +
          "exp8".center(13) + "|" +
          "exp9".center(13) + "|" +
          "exp10".center(13) + "|")
    print("-"*156)

    for limit in upper_limits:
        
        for row in time_table:
            print(row)
            print("-"*156)
