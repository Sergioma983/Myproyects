print("introduce los lados de cada triangulo: ")
x = int(input("x: "))
y = int(input("y: "))
z = int(input("z: "))

if x == y == z:
    print("Tu triangulo es equilatero")
elif x == y or y == z or z == x:
    print("Tu triangulo es isoceles")
else:
    print("tu triangulo es escaleno")
