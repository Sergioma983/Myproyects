import matplotlib.pyplot as plt
from threading import Thread
import time
import time_experiments as profile
import versions_primos_62 as vp


def is_relative_prime_v1(x, y):
    """[summary]
        Dos numeros x, y son primos relativos el unico divisor comun es el 1 
    Args:
        x ([int]): [description]
        y ([int]): [description]
    """
    m = min(x, y) + 1
    for d in range(2, m):
        if x % d == 0 and y % d == 0:
            return False
    return True


def table_relative_prime(size):
    tabla_primos = [[False]*size for _ in range(size)]

    for i in range(2, size):
        for j in range(2, size):
            tabla_primos[i][j] = is_relative_prime_v1(i, j)
    return tabla_primos


def main():

    #sizes = [300, 400, 500 ]
    #num_experiments = 3
    tic = time.time()
    size = 360
    tabla_primos = table_relative_prime(size)
    toc = time.time()
    print("table took time: ", toc-tic)
    plt.matshow(tabla_primos)
    plt.show()
    toc = time.time()
    print("plot took time: ", toc-tic)


if __name__ == "__main__":
    main()
