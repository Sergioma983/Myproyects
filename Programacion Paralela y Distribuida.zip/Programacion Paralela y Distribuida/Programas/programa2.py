import matplotlib.pyplot as plt


def len_collatz(n):
    """[summary]
    Regresa la longitud de la sucesion de collatz para el numero n

    la sucesion de collatz de numero 

    Args:
        num (int): [el numero base para iniciar la sucesion de collatz]
    """
    len = 1
    while n != 1:

        if n % 2 == 0:  # si el numero es par
            n /= 2
        else:
            n = n*3 + 1
        len += 1
    return len


numbers = []
lens = []
for a in range(2, 100):
    len = len_collatz(a)
    numbers.append(a)
    lens.append(len)
    print(f"{a}".center(5), "|".center(5), f"{len}".center(5))

plt.scatter(numbers, lens)
plt.title("conjetura de collatz ")
plt.xlabel('Numero')
plt.ylabel('Longitud')
plt.show()
