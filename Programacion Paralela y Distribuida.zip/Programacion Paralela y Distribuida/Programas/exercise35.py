while True:
    print("\n")
    hum_edad = int(input("Ingresa la edad de tu perro en años: "))

    if hum_edad < 0:
        print("La edad no puede ser negativa")
        exit()
    elif hum_edad <= 2:
        edad_perro = hum_edad * 10.5
    else:
        edad_perro = 21 + (hum_edad - 2)*4
    print("La edad de tu perro en años humanos es: ", edad_perro)

    repetir = input("¿Quieres verificar otra edad? si / no: ")
    if repetir == "no":
        break
print("\n")
print("Vuelve pronto")
