# print("Hello World!")

print("What is your name?")
name = input()
print("Hello, " + name)
