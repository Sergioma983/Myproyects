
decibels = float(input("Ingrese el numero de decibel: "))

if decibels > 0 and decibels < 40:
    print('Mas silencioso que Quiet room.')

elif decibels == 40:
    print('Lo mismo que un quiet room.')

elif decibels > 40 and decibels < 70:
    print('Mas silencioso que Alarm clock.')
elif decibels == 70:
    print('Lo mismo que una alarm clock.')

elif decibels > 70 and decibels < 106:
    print('Mas silencioso que lawn mower.')

elif decibels == 106:
    ('Los mismo que un lawn mower.')

elif decibels > 106 and decibels < 130:
    print(" Mas silencioso que jackhammer.")

elif decibels == 130:
    print('Los mismo que un jackhammer.')

elif decibels > 130:
    print('Mucho muy ruidoso.')

else:
    print('Ingresa un numero correcto.')

    print('Tu nivel de sonido es:')
