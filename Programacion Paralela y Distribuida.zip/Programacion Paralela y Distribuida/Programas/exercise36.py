while True:
    print("\n")
    letra = input("Ingresa una letra: ")
    if letra in ('a', 'e', 'i', 'o', 'u'):
        print("%s es una vocal." % letra)
    elif letra == 'y':
        print("Esta letra depende de como se escriba puede ser vocal o consonante.")
    else:
        print("%s es una consonante." % letra)
    repetir = input("¿Quieres verificar otra letra? si / no: ")
    if repetir == "no":
        break
print("\n")
