from threading import Thread
from time import sleep
import time_experiments as profile
from matplotlib import pyplot as plt

data = [0] * 4


def worker2(size, n):
    index = int(n)
    suma = 0
    numero = int(size/4)
    numero2 = numero*2
    numero3 = numero*3
    if n == "0":
        for i in range(0, numero+1):
            suma += i
    elif n == "1":
        for i in range(numero+1, numero2+1):
            suma += i
    elif n == "2":
        for i in range(numero2+1, numero3+1):
            suma += i
    elif n == "3":
        for i in range(numero3+1, int(size)+1):
            suma += i
    data[index] = suma


def perfilar_suma(size):
    for p in range(2):
        t = Thread(target=worker2, args=(size, str(p)))
        t.start()
        t.join()
    print("data contains: ")
    print(data[0]+data[1]+data[2]+data[3])


if __name__ == "__main__":
    size = range(int(1e7), int(1.1e8), 10000000)
    test = profile.run_experiments(perfilar_suma, size, 10, "4 Hilos")
