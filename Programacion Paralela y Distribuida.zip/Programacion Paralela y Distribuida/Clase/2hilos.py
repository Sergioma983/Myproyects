from threading import Thread
from time import sleep
import time_experiments as profile
from matplotlib import pyplot as plt

data = [0] * 2


def worker(size, n):
    index = int(n)
    suma = 0
    numero = int(size/2)
    if n == "0":
        for i in range(0, numero+1):
            suma += i
    elif n == "1":
        for i in range(numero+1, int(size)+1):
            suma += i
    data[index] = suma


def perfilar_suma(size):
    for p in range(2):
        t = Thread(target=worker, args=(size, str(p)))
        t.start()
        t.join()
    print("data contains: ")
    print(data[0]+data[1])


if __name__ == "__main__":
    size = range(int(1e7), int(1.1e8), 10000000)
    test = profile.run_experiments(perfilar_suma, size, 10, "2 Hilos")
