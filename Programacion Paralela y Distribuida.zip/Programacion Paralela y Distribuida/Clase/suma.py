suma = 0
for i in range(70000000):
    suma += i
    print(i)
print(suma)
