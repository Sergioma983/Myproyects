from threading import Thread
from time import sleep
import time_experiments1 as profile
from matplotlib import pyplot as plt

data = [0] * 2
data1 = [0] * 3
data2 = [0] * 4


def worker(size, n):
    index = int(n)
    suma = 0
    numero = int(size/2)
    if n == "0":
        for i in range(0, numero+1):
            suma += i
    elif n == "1":
        for i in range(numero+1, int(size)+1):
            suma += i
    data[index] = suma


def worker1(size, n):
    index = int(n)
    suma = 0
    numero = int(size/3)
    numero2 = numero*2
    numero3 = numero*3
    if n == "0":
        for i in range(0, numero+1):
            suma += i
    elif n == "1":
        for i in range(numero+1, numero2+1):
            suma += i
    elif n == "2":
        for i in range(numero2+1, numero3+1):
            suma += i
    data1[index] = suma


def worker2(size, n):
    index = int(n)
    suma = 0
    numero = int(size/4)
    numero2 = numero*2
    numero3 = numero*3
    if n == "0":
        for i in range(0, numero+1):
            suma += i
    elif n == "1":
        for i in range(numero+1, numero2+1):
            suma += i
    elif n == "2":
        for i in range(numero2+1, numero3+1):
            suma += i
    elif n == "3":
        for i in range(numero3+1, int(size)+1):
            suma += i
    data2[index] = suma


def perfilar_suma(size):
    for p in range(2):
        t = Thread(target=worker, args=(size, str(p)))
        t.start()
        t.join()
    print("data contains: ")
    print(data[0]+data[1])


def perfilar_suma1(size):
    for p in range(3):
        t = Thread(target=worker1, args=(size, str(p)))
        t.start()
        t.join()
    print("data contains: ")
    print(data1[0]+data1[1]+data1[2])


def perfilar_suma2(size):
    for p in range(4):
        t = Thread(target=worker2, args=(size, str(p)))
        t.start()
        t.join()
    print("data contains: ")
    print(data2[0]+data2[1]+data2[2]+data2[3])


def perfilar_suma3(size):
    suma = 0
    for i in range(size):
        suma += i
    print(suma)


if __name__ == "__main__":

    size = range(int(1e7), int(1e8), 10000000)

    test = profile.run_experiments(perfilar_suma, size, 10)

    for i in range(len(size)):
        plt.scatter([size[i]]*len(test[i]), test[i], color="blue")

    test = profile.run_experiments(perfilar_suma1, size, 10)

    for i in range(len(size)):
        plt.scatter([size[i]]*len(test[i]), test[i], color="black")

    test = profile.run_experiments(perfilar_suma2, size, 10)

    for i in range(len(size)):
        plt.scatter([size[i]]*len(test[i]), test[i], color="yellow")

    test = profile.run_experiments(perfilar_suma3, size, 10)

    for i in range(len(size)):
        plt.scatter([size[i]]*len(test[i]), test[i], color="green")

    plt.title(" Tiempos de perfilado de Suma con Hilos")
    plt.xlabel("Hilos")
    plt.ylabel("Tiempo S")
    plt.show()
