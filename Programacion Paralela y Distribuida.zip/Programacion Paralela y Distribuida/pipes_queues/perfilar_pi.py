import time
import versions_pi as vp
import matplotlib.pyplot as plt
import time_experiments as profile
import time_experiments_serial as profile_serial


def pipes():
    print("-"*30)
    print("pipes".center(30))
    print("-"*30)
    num_process = 4
    to_limit = int(1e8)

    # metodo pi concurrente con process y queues
    tic = time.time()
    result = vp.estimate_pi_process_pipes(0, to_limit, num_process)
    toc = time.time()
    print(
        f"Montecarlo concurrent PIPES with num_process {num_process} is:", result)
    print(" took time : ", toc-tic)
    print("-"*60)


def queque():
    print("-"*30)
    print("queues".center(30))
    print("-"*30)
    num_process = 4
    to_limit = int(1e8)

    # metodo pi concurrente con process y queues
    tic = time.time()
    result = vp.estimate_pi_process_queues(
        0, to_limit, num_process)
    toc = time.time()
    print(
        f"Montecarlo concurrent QUEUES with num_process {num_process} is:", result)
    print(" took time : ", toc-tic)
    print("-"*60)
    print("\n")


def serial():
    print("-"*30)
    print("Serial".center(30))
    print("-"*30)
    to_limit = int(1e8)

    # metodo pi concurrente con process y queues
    tic = time.time()
    result = vp.estimate_pi_serial(
        to_limit)
    toc = time.time()
    print(
        f"Montecarlo Serial is:", result)
    print(" took time : ", toc-tic)
    print("-"*60)


def perfilar():
    num_process = 4
    to_limit = [int(1e5), int(1e6), int(1e7), int(1e8)]

    params_profile = [{"from_limit": 0, "to_limit": limit, "num_process": num_process}
                      for limit in [int(1e5), int(1e6), int(1e7), int(1e8)]]

    profile.run_experiments(vp.estimate_pi_process_pipes, params_profile, 5,
                            f"Estimate pi con {num_process} procesos pipes", xlabel="procesos")

    params_profile1 = [{"from_limit": 0, "to_limit": limit, "num_process": num_process}
                       for limit in [int(1e5), int(1e6), int(1e7), int(1e8)]]

    profile.run_experiments(vp.estimate_pi_process_pipes, params_profile1, 5,
                            f"Estimate pi con {num_process} procesos queue", xlabel="procesos")

    profile_serial.run_experiments(vp.estimate_pi_serial, to_limit, 5,
                                   f"Estimate pi serial", xlabel="procesos")


if __name__ == "__main__":
    serial()
    pipes()
    queque()
    perfilar()
