import time
import versions_collatz as vp
import matplotlib.pyplot as plt
import time_experiments as profile
import time_experiments_serial as profile_serial


def pipes():
    print("-"*30)
    print("pipes")
    print("-"*30)
    num_process = 2
    from_limit = 0
    to_limit = 2500

    tic = time.time()
    result = vp.collatz_process_pipes(to_limit, num_process)
    toc = time.time()
    print("resultado: ", len(result))
    print("PIPES took time : ", toc-tic)
    plt.scatter(range(to_limit), result)
    plt.title("Collatz with process")
    plt.xlabel("n")
    plt.ylabel("len collatz")
    plt.show()


def queque():
    print("-"*30)
    print("queues")
    print("-"*30)

    from_limit = 0
    to_limit = 2500
    number_process = 2

    tic = time.time()
    result = vp.collatz_process_queues(to_limit, number_process)
    toc = time.time()
    print("resultado: ", len(result))
    print("QUEUES took time : ", toc-tic)
    plt.scatter(range(to_limit), result)
    plt.title("Collatz with process")
    plt.xlabel("n")
    plt.ylabel("len collatz")
    plt.show()


def serial():
    print("-"*30)
    print("serial")
    print("-"*30)

    from_limit = 0
    to_limit = 2500

    tic = time.time()
    result = vp.generate_table_collatz(from_limit, to_limit)
    toc = time.time()
    print("resultado: ", len(result))
    print("SERIAL took time : ", toc-tic)
    plt.scatter(range(to_limit), result)
    plt.title("Collatz with process")
    plt.xlabel("n")
    plt.ylabel("len collatz")
    plt.show()


def perfilar():
    num_process = 4
    size = [int(1e3), int(1e4), int(1e5), int(1e6)]

    profile_serial.run_experiments(vp.generate_table_collatz_serial, size, 5,
                                   f"Collatz serial", xlabel="procesos")

    params_profile1 = [{"size_table": limit, "num_process": num_process}
                       for limit in [int(1e3), int(1e4), int(1e5), int(1e6)]]

    profile.run_experiments(vp.collatz_process_pipes, params_profile1, 5,
                            f"Collatz con {num_process} procesos queue", xlabel="procesos")

    params_profile = [{"size_table": limit, "num_process": num_process}
                      for limit in [int(1e3), int(1e4), int(1e5), int(1e6)]]

    profile.run_experiments(vp.collatz_process_pipes, params_profile, 5,
                            f"Collatz con {num_process} procesos pipes", xlabel="procesos")


if __name__ == "__main__":
    perfilar()
