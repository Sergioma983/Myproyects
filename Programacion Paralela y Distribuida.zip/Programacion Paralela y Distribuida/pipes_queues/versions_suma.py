from threading import Thread
from multiprocessing import Process, Pipe
from multiprocessing import Process, Queue
from time import sleep
import time_experiments as profile
import time

max_num_threads = 10
partial_results = [0] * max_num_threads

# implementacion serial de la suma de numeros


def sum_in_range_serial(upper_limit):
    sum = 0
    for n in range(upper_limit):
        sum += n
    return sum


def sum_in_range1(lower_limit, upper_limit):
    sum = 0
    for n in range(lower_limit, upper_limit):
        sum += n
    return sum


def __sum_in_range_worker_threads(lower_limit, upper_limit, index_result):
    partial_results[index_result] = sum_in_range1(lower_limit, upper_limit-1)

# implementacion con hilos de la suma de numeros


def sum_in_range_with_threads(lower_limit, upper_limit, num_threads):
    num_threads = max(num_threads, max_num_threads)

    # distribuir la carga de trabajo entre los hilos
    size_chunk = (upper_limit - lower_limit) // num_threads
    params_sum = [{"lower_limit": t * size_chunk,
                   "upper_limit": (t + 1) * size_chunk,
                   "index_result": t
                   } for t in range(num_threads)]
    params_sum[-1]["upper_limit"] = upper_limit+1

    # crear los hilos y asignarlas las cargas de trabajo
    workers = []
    for p in params_sum:
        t = Thread(target=__sum_in_range_worker_threads,  kwargs=p)
        t.start()
        workers.append(t)

    # esperar que los hilos terminen el trabajo asignado
    for t in workers:
        t.join()

    # colectar los resultados parciales para obtener el resultado
    total_sum = 0
    for value in partial_results:
        total_sum += value
    return total_sum


# Suma con pipes

def sum_in_range(from_limit, to_limit):
    sum = 0
    for n in range(from_limit, to_limit):
        sum += n
    return sum


def __sum_in_range_worker_pipes(sum_from, sum_to, child_pipe_connection):
    partial_sum = sum_in_range(sum_from, sum_to)
    child_pipe_connection.send(partial_sum)
    child_pipe_connection.close()


def sum_in_range_process_pipes(sum_from, sum_to, num_process):
    # distribuir la carga de trabajo
    size_chunk = (sum_to - sum_from) // num_process
    params = [{"sum_from": n * size_chunk,
               "sum_to": (n + 1)*size_chunk,
               **dict(zip(["parent_pipe_connection", "child_pipe_connection"], Pipe()))
               } for n in range(num_process)
              ]
    params[-1]["sum_to"] = sum_to
    # crear los procesos hijos y asinarles las cargas de trabajo
    for p in params:
        job = Process(target=__sum_in_range_worker_pipes, kwargs=filter(
            lambda item: item[0] != "parent_pipe_connection", p.items()))
        job.start()

    total_sum = 0
    for j in params:
        total_sum += j["parent_pipe_connection"].recv()

    return total_sum

# version queques


def sum_in_range2(from_limit, to_limit):
    sum = 0
    for n in range(from_limit, to_limit):
        sum += n

    return sum


def __sum_in_range__queue_worker(sum_from, sum_to, queue_connection):
    # do the work
    partial_sum = sum_in_range2(sum_from, sum_to)
    # send the result to parent process via queue
    queue_connection.put(partial_sum)


def sum_in_range_process_queues(from_limit, to_limit, num_process):
    # mechanism IPC
    queue_connection = Queue()
    # distribuir la carga de trabajo
    size_chunk = (to_limit - from_limit) // num_process
    params = [{"sum_from": n * size_chunk,
               "sum_to": (n + 1)*size_chunk,
               "queue_connection": queue_connection} for n in range(num_process)
              ]
    params[-1]["sum_to"] = to_limit

    # crear los procesos hijos y asignarles las cargas de trabajo
    jobs = []
    for p in params:
        worker = Process(target=__sum_in_range__queue_worker, kwargs=p)
        worker.start()
        jobs.append(worker)

    # esperar a que los hijos terminen el trabajo asignado
    for j in jobs:
        j.join()

    #  y colectamos resultados parciales para obtener el resultado final
    total_sum = 0
    while queue_connection.empty() is False:
        total_sum += queue_connection.get()

    return total_sum
