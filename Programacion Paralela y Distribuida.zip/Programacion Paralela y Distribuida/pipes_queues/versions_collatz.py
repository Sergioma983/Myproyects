from multiprocessing import Process, Queue
from multiprocessing import Process, Pipe
import time


def generate_table_collatz_serial(to_limit):
    table = []
    for n in range(to_limit):
        table.append(len_collatz(n))
    return table


def len_collatz(n):
    """[summary]
    Regresa la longitud de la sucesion de collatz para el numero n

    la sucesion de collatz de numero

    Args:
        num (int): [el numero base para iniciar la sucesion de collatz]
    """
    if n < 2:
        return n

    len = 1
    while n != 1:
        if n % 2 == 0:  # si el numero es par
            n //= 2
        else:
            n = n*3 + 1
        len += 1

    return len


def generate_table_collatz(from_limit, to_limit):
    table = []
    for n in range(from_limit, to_limit):
        table.append(len_collatz(n))
    return table


def __table_collatz_worker_queues(from_limit, to_limit, queue_connection):
    partial_collatz = generate_table_collatz(from_limit, to_limit)
    if from_limit == 0:
        time.sleep(5)
    queue_connection.put((from_limit, to_limit, partial_collatz))


def collatz_process_queues(size_table, num_process):
    # mechanism IPC
    queue_connection = Queue()
    # distribuir la carga de trabajo
    size_chunk = (size_table) // num_process
    params = [{"from_limit": n * size_chunk,
               "to_limit": (n + 1)*size_chunk,
               "queue_connection": queue_connection} for n in range(num_process)
              ]
    params[-1]["to_limit"] = size_table

    # crear los procesos hijos y asinarles las cargas de trabajo
    jobs = []
    for p in params:
        worker = Process(target=__table_collatz_worker_queues, kwargs=p)
        worker.start()
        jobs.append(worker)

    # esperar a que los hijos envien los resultados parcial
    for j in jobs:
        j.join()

    # esperar a que los hilos terminen el trabajo asignado
    orbits = [0] * size_table

    while queue_connection.empty() is False:
        from_index, to_index, partial_table = queue_connection.get()
        orbits[from_index:to_index] = partial_table

    # colectar los resultados parciales para obtener el resultado total
    #   esta parte es trivial para Collatz por que vas a regresar
    #   el arreglo que rellenan los hilos con las orbitas
    #
    return orbits


def __table_collatz_worker_pipes(from_limit, to_limit, child_pipe_connection):
    partial_collatz = generate_table_collatz(from_limit, to_limit)
    child_pipe_connection.send(partial_collatz)
    child_pipe_connection.close()


def collatz_process_pipes(size_table, num_process):
    orbits = [0]*(size_table + 2)
    # distribuir la carga de trabajo
    size_chunk = (size_table) // num_process
    params = [{"from_limit": n * size_chunk,
               "to_limit": (n + 1)*size_chunk,
               **dict(zip(["parent_pipe_connection", "child_pipe_connection"], Pipe()))
               } for n in range(num_process)
              ]
    params[-1]["to_limit"] = size_table
    # crear los procesos hijos y asinarles las cargas de trabajo
    for p in params:
        job = Process(target=__table_collatz_worker_pipes, kwargs=filter(
            lambda item: item[0] != "parent_pipe_connection", p.items()))
        job.start()

    # esperar a que los hilos terminen el trabajo asignado
    orbits = []
    for j in params:
        list_partial = j["parent_pipe_connection"].recv()
        orbits.extend(list_partial)

    # colectar los resultados parciales para obtener el resultado total
    #   esta parte es trivial para Collatz por que vas a regresar
    #   el arreglo que rellenan los hilos con las orbitas
    #
    return orbits
