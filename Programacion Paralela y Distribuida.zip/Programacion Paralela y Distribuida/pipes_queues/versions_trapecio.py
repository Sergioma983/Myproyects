from multiprocessing import Process, Queue
from multiprocessing import Process, Pipe
import math as m


def f(x):
    return 1.25*m.sin(x/2) + 3


def trapezoidal_integration(function_to_integrate, lower_limit, upper_limit, num_divisions):
    """
        Implementa la integracion por el metodo de los trapecios
        dada una funcion el area bajo la curva se aproxima dividiendo el
        intervalo de integracion en num_divisions y
        Args:
            function_to_integrate (function): la funcion escalar a integrar
            lower_limit (float): el limite inferior del intervalo de integracion
            upper_limit ([type]): el limite superior del intervalo de integracion
            num_divisions ([type]): el numero de divisiones a realizar
    Return (float): el valor de la aproximado de la integral """

    dx = (upper_limit - lower_limit) / num_divisions

    area = 0

    for n in range(1, num_divisions):
        area += function_to_integrate(lower_limit + n*dx)

    area = 0.5*function_to_integrate(lower_limit) + \
        area + 0.5*function_to_integrate(upper_limit)
    area *= dx

    return area


def __trapezoidal_integration_worker_pipes(function_to_integrate, from_limit, num_trapezoids, size_dx, child_pipe_connection):
    partial_area = 0

    for n in range(1, num_trapezoids):
        partial_area += function_to_integrate(from_limit + n*size_dx)

    partial_area = 0.5*function_to_integrate(from_limit) + partial_area + \
        0.5*function_to_integrate(from_limit + num_trapezoids*size_dx)
    partial_area *= size_dx

    child_pipe_connection.send(partial_area)
    child_pipe_connection.close()


def trapezoidal_integration_with_process_pipes(function_to_integrate, lower_limit, upper_limit, num_divisions, num_process):
    size_chunk_interval = (upper_limit - lower_limit) // num_process
    size_chunk_divisions = num_divisions // num_process
    size_dx = (upper_limit - lower_limit) / num_divisions
    # print("size_dx", size_dx)
    # print("size_chunk_divisions", size_chunk_divisions)
    # print("size_chunk_interval", size_chunk_interval)

    params = [{"function_to_integrate": function_to_integrate,
               "from_limit": n * size_chunk_divisions * size_dx + lower_limit,
               "num_trapezoids": size_chunk_divisions,
               "size_dx": size_dx,
               **dict(zip(["parent_pipe_connection", "child_pipe_connection"], Pipe()))
               } for n in range(num_process)
              ]
    params[-1]["num_trapezoids"] = size_chunk_divisions + \
        num_divisions % num_process

    # crear los procesos hijos y asinarles las cargas de trabajo
    for p in params:
        job = Process(target=__trapezoidal_integration_worker_pipes, kwargs=filter(
            lambda item: item[0] != "parent_pipe_connection", p.items()))
        job.start()

    area = 0
    for j in params:
        area += j["parent_pipe_connection"].recv()

    return area


def __trapezoidal_integration_worker_queue(function_to_integrate, from_limit, num_trapezoids, size_dx, queue_connection):
    partial_area = 0

    for n in range(1, num_trapezoids):
        partial_area += function_to_integrate(from_limit + n*size_dx)

    partial_area = 0.5*function_to_integrate(from_limit) + partial_area + \
        0.5*function_to_integrate(from_limit + num_trapezoids*size_dx)
    partial_area *= size_dx

    queue_connection.put(partial_area)


def trapezoidal_integration_with_process_queues(function_to_integrate, lower_limit, upper_limit, num_divisions, num_process):
    # distribuir la carga de trabajo y creamos los pipes
    queue_connection = Queue()
    size_chunk_interval = (upper_limit - lower_limit) // num_process
    size_chunk_divisions = num_divisions // num_process
    size_dx = (upper_limit - lower_limit) / num_divisions
    # print("size_dx", size_dx)
    # print("size_chunk_divisions", size_chunk_divisions)
    # print("size_chunk_interval", size_chunk_interval)

    params = [{"function_to_integrate": function_to_integrate,
               "from_limit": n * size_chunk_divisions * size_dx + lower_limit,
               "num_trapezoids": size_chunk_divisions,
               "size_dx": size_dx,
               "queue_connection": queue_connection} for n in range(num_process)
              ]
    params[-1]["num_trapezoids"] = size_chunk_divisions + \
        num_divisions % num_process

    # asignamos las cargas de trabajo
    jobs = []
    for p in params:
        worker = Process(
            target=__trapezoidal_integration_worker_queue, kwargs=p)
        worker.start()
        jobs.append(worker)

    # esperar a que los hijos envien los resultados parcial
    for j in jobs:
        j.join()

    area = 0
    while queue_connection.empty() is False:
        area += queue_connection.get()

    return area
