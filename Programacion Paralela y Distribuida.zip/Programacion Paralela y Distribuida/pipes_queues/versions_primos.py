import matplotlib.pyplot as plt
import time
from multiprocessing import Process, Pipe
from multiprocessing import Process, Queue


def table_relative_prime(size):
    tabla_primos = [[False]*size for _ in range(size)]

    for i in range(0, size):
        for j in range(0, size):
            tabla_primos[i][j] = is_relative_prime(i, j)

    return tabla_primos


def is_relative_prime(x, y):
    m = min(x, y) + 1

    for d in range(2, m):
        if x % d == 0 and y % d == 0:
            return False
    return True


def __chunk_table_primos_relativos_worker_pipes(from_row, to_row, size_row, child_connection):
    # crea y rellena los renglones de la tabla de primos
    num_rows = to_row - from_row
    sub_table = [[False]*size_row for _ in range(num_rows)]

    for i in range(0, num_rows):
        for j in range(0, size_row):
            sub_table[i][j] = is_relative_prime(i + from_row, j)

    child_connection.send(sub_table)
    child_connection.close()


def generate_table_primos_relativos_with_process_pipes(size_table, num_process):
    # distribuir la carga de trabajo entre los procesos
    size_chunk = size_table // num_process
    params_worker = [{"from_row": t * size_chunk,
                      "to_row": (t + 1) * size_chunk,
                      "size_row": size_table,
                      **dict(zip(["parent_connection", "child_connection"], Pipe()))
                      }for t in range(num_process)]

    params_worker[-1]["to_row"] = size_table

    # asignamos las cargas de trabajo
    for p in params_worker:
        p = Process(target=__chunk_table_primos_relativos_worker_pipes, kwargs=filter(
            lambda item: item[0] != "parent_connection", p.items()))
        p.start()

    # esperar a que los procesos terminen el trabajo asignado
    # y colectar resultados parciales para generar el resultado final

    # all_table =  [[False]*size_table for _ in range(size_table)]
    all_table = []
    for p in params_worker:
        sub_table = p["parent_connection"].recv()
        all_table.extend(sub_table)

        # from_rom = p["from_row"]
        # to_row = p["to_row"]
        # num_rows = p["to_row"] - p["from_row"]
        # for i in range (num_rows):
        #     for j in range(size_table):
        #         all_table[i][j] = sub_table[i-num_rows][j]

    return all_table


def __chunk_table_primos_relativos_worker_queues(from_row, to_row, size_row, queue_connection):
    # crea y rellena los renglones de la tabla de primos
    num_rows = to_row - from_row
    sub_table = [[False]*size_row for _ in range(num_rows)]

    for i in range(0, num_rows):
        for j in range(0, size_row):
            sub_table[i][j] = is_relative_prime(i + from_row, j)

    queue_connection.put((from_row, to_row, sub_table))


def generate_table_primos_relativos_with_process_queues(size_table, num_process):
    # mechanism IPC
    queue_connection = Queue()
    # distribuir la carga de trabajo entre los procesos
    size_chunk = size_table // num_process
    params_worker = [{"from_row": t * size_chunk,
                      "to_row": (t + 1) * size_chunk,
                      "size_row": size_table,
                      "queue_connection": queue_connection} for t in range(num_process)]

    params_worker[-1]["to_row"] = size_table

    # asignamos las cargas de trabajo
    jobs = []
    for p in params_worker:
        worker = Process(
            target=__chunk_table_primos_relativos_worker_queues, kwargs=p)
        worker.start()
        jobs.append(worker)

    # esperar a que los hijos envien los resultados parcial
    for j in jobs:
        j.join()

    # all_table =  [[False]*size_table for _ in range(size_table)]
    all_table = [0] * size_table
    while queue_connection.empty() is False:

        from_index, to_index, partial_table = queue_connection.get()

        all_table[from_index:to_index] = partial_table

    return all_table
