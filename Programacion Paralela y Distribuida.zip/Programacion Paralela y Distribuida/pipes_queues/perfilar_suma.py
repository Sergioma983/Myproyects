import time
import versions_suma as vp
import matplotlib.pyplot as plt
import time_experiments as profile
import time_experiments_serial as profile_serial


def pipes():
    print("-"*30)
    print("pipes".center(30))
    print("-"*30)
    from_limit = 0
    to_limit = int(1e8)
    num_process = 4

    # suma concurrente con process y queues
    tic = time.time()
    result = vp.sum_in_range_process_pipes(from_limit, to_limit, num_process)
    toc = time.time()
    print(f"sum concurrent PIPES with num_process {num_process} is:", result)
    print(" took time : ", toc-tic)
    print("-"*60)


def queque():
    print("-"*30)
    print("queque".center(30))
    print("-"*30)
    from_limit = 0
    to_limit = int(1e8)
    num_process = 4

    # suma concurrente con process y queues
    tic = time.time()
    result = vp.sum_in_range_process_queues(from_limit, to_limit, num_process)
    toc = time.time()
    print(f"sum concurrent QUEUES with num_process {num_process} is:", result)
    print(" took time : ", toc-tic)
    print("-"*60)
    print("\n")


def serial():
    print("-"*30)
    print("serial".center(30))
    print("-"*30)
    to_limit = [int(1e4), int(1e5), int(1e6), int(1e7)]
    limit = int(1e8)

    # suma concurrente con process y queues
    tic = time.time()
    result = vp.sum_in_range_serial(limit)
    toc = time.time()
    print(f"sum concurrent SERIAL with num_process is:", result)
    print(" took time : ", toc-tic)
    print("-"*60)


def perfilar():
    num_process = 4
    to_limit = [int(1e4), int(1e5), int(1e6), int(1e7)]

    params_profile = [{"sum_from": 0, "sum_to": limit, "num_process": num_process}
                      for limit in [int(1e4), int(1e5), int(1e6), int(1e7)]]

    profile.run_experiments(
        vp.sum_in_range_process_pipes, params_profile, 5, f"Suma de {num_process} pipes process", xlabel="procesos")

    params_profile1 = [{"from_limit": 0, "to_limit": limit, "num_process": num_process}
                       for limit in [int(1e4), int(1e5), int(1e6), int(1e7)]]

    profile.run_experiments(
        vp.sum_in_range_process_queues, params_profile1, 5, f"Suma Serial de {num_process} queues process", xlabel="procesos")

    profile_serial.run_experiments(
        vp.sum_in_range_serial, to_limit, 5, f"Suma Serial", xlabel="procesos")


if __name__ == "__main__":
    serial()
    pipes()
    queque()
    perfilar()
