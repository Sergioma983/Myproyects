from multiprocessing import Process, Pipe
import random
from multiprocessing import Process, Queue


def estimate_pi_serial(num_points):
    """

    """
    num_inside = 0

    for _ in range(num_points):
        x = random.random()
        y = random.random()
        if x**2 + y**2 <= 1.0:
            num_inside += 1

    aproximate_pi = 4*num_inside / num_points

    return aproximate_pi


def estimate_pi(from_limit, to_limit):
    print(from_limit)
    print(to_limit)
    num_inside = 0
    for _ in range(from_limit, to_limit):
        x = random.random()
        y = random.random()
        if x**2 + y**2 <= 1.0:
            num_inside += 1

    return num_inside


def __estimate_pi_worker_pipes(from_limit, to_limit, child_pipe_connection):
    partial_pi = estimate_pi(from_limit, to_limit)
    child_pipe_connection.send(partial_pi)
    child_pipe_connection.close()


def estimate_pi_process_pipes(from_limit, to_limit, num_process):
    # distribuir la carga de trabajo
    size_chunk = (to_limit - from_limit) // num_process
    params = [{"from_limit": n * size_chunk,
               "to_limit": (n + 1)*size_chunk,
               **dict(zip(["parent_pipe_connection", "child_pipe_connection"], Pipe()))
               } for n in range(num_process)
              ]
    params[-1]["to_limit"] = to_limit

    # crear los procesos hijos y asinarles las cargas de trabajo
    for p in params:
        job = Process(target=__estimate_pi_worker_pipes, kwargs=filter(
            lambda item: item[0] != "parent_pipe_connection", p.items()))
        job.start()

    # esperar a que los hilos terminen el trabajo asignado
    total_aproximate = 0
    for j in params:
        total_aproximate += j["parent_pipe_connection"].recv()
    aproximate_pi = 4*total_aproximate / to_limit

    return aproximate_pi


def estimate_pi(from_limit, to_limit):
    num_inside = 0
    for _ in range(from_limit, to_limit):
        x = random.random()
        y = random.random()
        if x**2 + y**2 <= 1.0:
            num_inside += 1

    return num_inside


def __estimate_pi_worker_queues(from_limit, to_limit, queue_connection):
    partial_pi = estimate_pi(from_limit, to_limit)
    queue_connection.put(partial_pi)


def estimate_pi_process_queues(from_limit, to_limit, num_process):
    # mechanism IPC
    queue_connection = Queue()
    # distribuir la carga de trabajo
    size_chunk = (to_limit - from_limit) // num_process
    params = [{"from_limit": n * size_chunk,
               "to_limit": (n + 1)*size_chunk,
               "queue_connection": queue_connection} for n in range(num_process)
              ]
    params[-1]["to_limit"] = to_limit

    # crear los procesos hijos y asinarles las cargas de trabajo
    # asignamos las cargas de trabajo
    jobs = []
    for p in params:
        worker = Process(target=__estimate_pi_worker_queues, kwargs=p)
        worker.start()
        jobs.append(worker)

    # esperar a que los hijos envien los resultados parcial
    for j in jobs:
        j.join()

    area = 0
    while queue_connection.empty() is False:
        area += queue_connection.get()
    aproximate_pi = 4*area / to_limit

    return aproximate_pi
