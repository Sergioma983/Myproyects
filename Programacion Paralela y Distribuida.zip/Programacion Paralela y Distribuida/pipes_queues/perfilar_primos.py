import time
import versions_primos as vp
import matplotlib.pyplot as plt
import time_experiments as profile
import time_experiments_serial as profile_serial


def pipes():
    print("-"*30)
    print("pipes".center(30))
    print("-"*30)
    num_process = 4
    size = 1000

    tic = time.time()
    tabla_primos2 = vp.generate_table_primos_relativos_with_process_pipes(
        size, num_process)
    toc = time.time()
    print("Primos CONCURRENT PIPES table took time: ", toc-tic)

    plt.matshow(tabla_primos2)
    plt.show()
    toc = time.time()
    print("plot took time: ", toc-tic)
    print("-"*60)


def queque():
    print("-"*30)
    print("queues".center(30))
    print("-"*30)
    num_process = 4
    size = 1000

    tic = time.time()
    tabla_primos3 = vp.generate_table_primos_relativos_with_process_pipes(
        size, num_process)
    toc = time.time()
    print("Primos CONCURRENT QUEUES table took time: ", toc-tic)

    plt.matshow(tabla_primos3)
    plt.show()
    toc = time.time()
    print("plot took time: ", toc-tic)
    print("-"*60)
    print("\n")


def serial():
    print("-"*30)
    print("serial".center(30))
    print("-"*30)

    size = 1000

    tic = time.time()
    tabla_primos1 = vp.table_relative_prime(size)
    toc = time.time()
    print("SERIAL took time: ", toc-tic)

    plt.matshow(tabla_primos1)
    plt.show()
    toc = time.time()
    print("plot took time: ", toc-tic)
    print("-"*60)


def perfilar():
    size = [200, 400, 600, 800, 1000]
    num_process = 4

    params_profile = [{"size_table": limit, "num_process": num_process}
                      for limit in [200, 400, 600, 800, 1000]]

    profile_serial.run_experiments(vp.table_relative_prime, size, 5,
                                   f"Primos relativos Serial", xlabel="procesos")

    profile.run_experiments(vp.generate_table_primos_relativos_with_process_pipes, params_profile, 5,
                            f"Primos relativos con {num_process} procesos queue", xlabel="procesos")

    profile.run_experiments(vp.generate_table_primos_relativos_with_process_pipes, params_profile, 5,
                            f"Primos relativos con {num_process} procesos pipes", xlabel="procesos")


if __name__ == "__main__":

    perfilar()
