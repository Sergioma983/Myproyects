import time
import versions_trapecio as vp
import matplotlib.pyplot as plt
import time_experiments as profile
import math


def f(x):
    return 1.25*math.sin(x/2) + 3


def pipes():
    print("-"*30)
    print("pipes".center(30))
    print("-"*30)
    num_process = 4
    num_divisions = int(1e7)

    # metodo traperio concurrente con process y queues
    tic = time.time()
    result = vp.trapezoidal_integration_with_process_pipes(
        f, 1, 9, num_divisions, num_process)
    toc = time.time()
    print(
        f"Trapezoidal concurrent QUEUES with num_process {num_process} is:", result)
    print(" took time : ", toc-tic)
    print("-"*60)


def queque():
    print("-"*30)
    print("queues".center(30))
    print("-"*30)
    num_process = 4
    num_divisions = int(1e7)

    # metodo traperio concurrente con process y queues
    tic = time.time()
    result = vp.trapezoidal_integration_with_process_queues(
        f, 1, 9, num_divisions, num_process)
    toc = time.time()
    print(
        f"Trapezoidal concurrent QUEUES with num_process {num_process} is:", result)
    print(" took time : ", toc-tic)
    print("-"*60)
    print("\n")


def serial():
    print("-"*30)
    print("Serial".center(30))
    print("-"*30)
    num_divisions = int(1e7)

    # metodo traperio concurrente con process y queues
    tic = time.time()
    result = vp.trapezoidal_integration(
        f, 1, 9, num_divisions)
    toc = time.time()
    print(
        f"Trapezoidal Serial is:", result)
    print(" took time : ", toc-tic)
    print("-"*60)


def perfilar():
    num_process = 4

    params_profile = [{"function_to_integrate": f, "lower_limit": 1, "upper_limit": 9, "num_divisions": limit, "num_process": num_process}
                      for limit in [int(1e4), int(1e5), int(1e6), int(1e7)]]

    profile.run_experiments(
        vp.trapezoidal_integration_with_process_pipes, params_profile, 5, f"Integral definida, método del trapecio con {num_process} pipes process", xlabel="procesos")

    params_profile1 = [{"function_to_integrate": f, "lower_limit": 1, "upper_limit": 9, "num_divisions": limit, "num_process": num_process}
                       for limit in [int(1e4), int(1e5), int(1e6), int(1e7)]]

    profile.run_experiments(
        vp.trapezoidal_integration_with_process_queues, params_profile1, 5, f"Integral definida, método del trapecio con {num_process} queue process", xlabel="procesos")

    params_profile2 = [{"function_to_integrate": f, "lower_limit": 1, "upper_limit": 9, "num_divisions": limit}
                       for limit in [int(1e4), int(1e5), int(1e6), int(1e7)]]

    profile.run_experiments(
        vp.trapezoidal_integration, params_profile2, 5, f"Integral definida, método del trapecio serial process", xlabel="procesos")


if __name__ == "__main__":
    serial()
    pipes()
    queque()
    perfilar()
