import matplotlib.pyplot as plt
from threading import Thread
import time
import time_experiments as profile

table = []
max_num_threads = 10


def tabla_relative_prime(size):
    tabla_primos = [[False]*size for _ in range(size)]
    for i in range(2, size):
        for j in range(2, size):
            tabla_primos[i][j] = is_relative_prime(i, j)


def is_relative_prime(x, y):

    m = min(x, y) + 1

    for d in range(2, m):
        if x % d == 0 and y % d == 0:
            return False
    return True


def __chunk_relative_primes_worker(from_row, to_row, size_row):
    # rellena en la tabla/arreglo global orbits las orbitas desde
    # from_limit hasta  to_limit
    for i in range(from_row, to_row):
        for j in range(0, size_row):
            table[i][j] = is_relative_prime(i, j)


def generate_table_relative_primes_with_threads(size_table, num_threads):
    global table

    table = [[False]*size_table for _ in range(size_table)]
    num_threads = max(num_threads, max_num_threads)

    # distribuir la carga de trabajo entre los hilos
    size_chunk = (size_table) // num_threads
    params_worker = [{"from_row": t * size_chunk,
                      "to_row": (t + 1) * size_chunk,
                      "size_row": size_table
                      }for t in range(num_threads)]

    params_worker[-1]["to_row"] = size_table

    # crear hilos y asignarles las cargas de trabajo
    workers = []
    for p in params_worker:
        t = Thread(target=__chunk_relative_primes_worker, kwargs=p)
        t.start()
        workers.append(t)

    # esperar a que los hilos terminen el trabajo asignado
    for t in workers:
        t.join()


def main():
    for num_threads in range(2, 9):
        params_profile = [{"size_table": limit, "num_threads": num_threads}
                          for limit in (range(100, 400, 50))]
        profile.run_experiments(
            generate_table_relative_primes_with_threads, params_profile, 10, "Primos relativos")


if __name__ == "__main__":
    main()
