import matplotlib.pyplot as plt
from threading import Thread
import time
import time_experiments as profile

orbits = []

max_num_threads = 10


def len_collatz(n):
    """[summary]
    Regresa la longitud de la sucesion de collatz para el numero n

    la sucesion de collatz de numero

    Args:
        num (int): [el numero base para iniciar la sucesion de collatz]
    """
    if n < 2:
        return n

    len = 1
    while n != 1:

        if n % 2 == 0:  # si el numero es par
            n //= 2
        else:
            n = n*3 + 1
        len += 1
    return len


def generate_table_collatz(size_table):
    table = []
    for n in range(2, size_table):
        table.append(len_collatz(n))
    return table


def __chunk_table_collatz_worker(from_limit, to_limit):
    # rellena en la tabla/arreglo global orbits las orbitas desde
    # from_limit hasta  to_limit
    for n in range(from_limit, to_limit):
        orbits[n] = len_collatz(n)


def generate_table_collatz_with_threads(size_table, num_threads):
    global orbits
    orbits = [0]*(size_table + 2)
    num_threads = max(num_threads, max_num_threads)
    # distribuir la carga de trabajo entre los hilos
    size_chunk = (size_table) // num_threads
    params_worker = [{"from_limit": t * size_chunk,
                      "to_limit": (t + 1) * size_chunk
                      }for t in range(num_threads)]

    params_worker[-1]["to_limit"] = size_table + 1

    # crear hilos y asignarles las cargas de trabajo
    workers = []
    for p in params_worker:
        t = Thread(target=__chunk_table_collatz_worker, kwargs=p)
        t.start()
        workers.append(t)

    # esperar a que los hilos terminen el trabajo asignado
    for t in workers:
        t.join()

    # colectar los resultados parciales para obtener el resultado total
    #   esta parte es trivial para Collatz por que vas a regresar
    #   el arreglo que rellenan los hilos con las orbitas
    #

    return orbits


def main():
    for num_threads in range(2, 8):
        params_profile = [
            {"size_table": int(100000), "num_threads": num_threads},
        ]
        profile.run_experiments(
            generate_table_collatz_with_threads, params_profile, 1, "collatz")


if __name__ == "__main__":
    main()
