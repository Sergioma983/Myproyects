
from threading import Thread
from time import sleep

import time_experiments as profile

max_num_threads = 10
partial_results = [0] * max_num_threads

# implementacion de collatz


def collatz(n):
    """
    Regresa la longuitud de la sucesion de Collatz para el numero n

    La secuencia de Collatz de un número $n$ se construye de forma
    recurrente a partir de la siguiente función:

            n / 2 si n es par

        n -----> 3*n + 1 si n es par

        la sucesion de collatz es finita y termina en 1

        p.e si n = 5, entonces la sucesion correspondiente es:
            si n = 5 tenemos 16, 8, 4, 2, 1
            si n = 7 tenemos = 22, 11, 34, 17 ..

    Args:
        n (int): el numero base para iniciar la sucesion de collatz
    """

    len = 1

    while n != 1:
        if n % 2 == 0:  # si el numero es par
            n /= 2
        else:
            n = n*3 + 1
        len += 1
    return len


def __collatz_worker(n, index_result):
    partial_results[index_result] = collatz(n)


# implementacion con hilos para collatz
def collatz_threads(n, num_threads):
    num_threads = max(num_threads, max_num_threads)

    # distribuir la carga de trabajo entre los hilos
    size_chunk = (n) // num_threads
    params_sum = [{"n": size_chunk,
                   "index_result": t
                   } for t in range(num_threads)]
    params_sum[-1]["n"] += n - (num_threads * size_chunk)

    # crear los hilos y asignarlas las cargas de trabajo
    workers = []
    for p in params_sum:
        t = Thread(target=__collatz_worker, kwargs=p)
        t.start()
        workers.append(t)

    # esperar que los hilos terminen el trabajo asignado
    for t in workers:
        t.join()

    # colectar los resultados parciales para obtener el resultado
    result = 0
    for value in partial_results:
        result += value

    return result


if __name__ == "__main__":
    for num_threads in range(2, 9):
        params_profile = [{"n": limit, "num_threads": num_threads}
                          for limit in (range(1000000, 5000000 + 1, 500000))]

        profile.run_experiments(collatz_threads, params_profile,
                                10, f"Suma de {num_threads} hilos", xlabel="hilos")
