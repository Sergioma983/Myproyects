from threading import Thread
from time import sleep

import time_experiments as profile

max_num_threads = 10
partial_results = [0] * max_num_threads

# implementacion serial de la suma de numeros


def len_collatz(n):
    """[summary]
    Regresa la longitud de la sucesion de collatz para el numero n

    la sucesion de collatz de numero

    Args:
        num (int): [el numero base para iniciar la sucesion de collatz]
    """
    if n < 2:
        return n

    len = 1
    while n != 1:
        if n % 2 == 0:  # si el numero es par
            n //= 2
        else:
            n = n*3 + 1
        len += 1
    return len


def collatz_worker(upper_limit, index_result):
    partial_results[index_result] = len_collatz(upper_limit)

# implementacion con hilos de la suma de numeros


def collatz_with_threads(upper_limit, num_threads):
    num_threads = max(num_threads, max_num_threads)

    # distribuir la carga de trabajo entre los hilos
    size_chunk = (upper_limit) // num_threads
    params_sum = [{"upper_limit": (t + 1) * size_chunk,
                   "index_result": t
                   } for t in range(num_threads)]
    params_sum[-1]["upper_limit"] = upper_limit

    # crear los hilos y asignarlas las cargas de trabajo
    workers = []
    for p in params_sum:
        t = Thread(target=collatz_worker,  kwargs=p)
        t.start()
        workers.append(t)

    # esperar que los hilos terminen el trabajo asignado
    for t in workers:
        t.join()

    return partial_results[9]


if __name__ == "__main__":

    for i in range(100000, 550000, 500000):
        result = len_collatz(i)
        print("collatz: ", result)

    for num_threads in range(2, 9):
        params_profile = [{"upper_limit": limit, "num_threads": num_threads}
                          for limit in (range(100000, 550000, 500000))]

    profile.run_experiments(collatz_with_threads,
                            params_profile, 10,  f"Suma de {num_threads} hilos", xlabel="hilos")
