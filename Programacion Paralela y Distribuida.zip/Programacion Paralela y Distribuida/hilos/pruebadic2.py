def __sum_in_range_worker(upper_limit, index_result):
    print("-"*50)
    print("upper_limit", upper_limit)
    print("index_result", index_result)


upper_limit = 100000
num_threads = 2

size_chuck = (upper_limit) // num_threads

params_sum = [{
    "upper_limit": (t + 1) * size_chuck,
    "index_result": t
} for t in range(num_threads)
]
params_sum[-1]["upper_limit"] = upper_limit

for p in params_sum:
    __sum_in_range_worker(**p)
