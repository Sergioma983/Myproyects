def collatz(num):
    sec = [num]
    while num > 1:
        if num % 2 == 0:
            num //= 2
        else:
            num = num * 3 + 1

        sec.append(num)

    return sec


for i in range(100000, 600000, 50000):
    secuencia = collatz(i)
    for a in secuencia:
        print(a, end=" ")
    print("\n")


def len_collatz(n):
    """[summary]
    Regresa la longitud de la sucesion de collatz para el numero n

    la sucesion de collatz de numero

    Args:
        num (int): [el numero base para iniciar la sucesion de collatz]
    """
    if n < 2:
        return n

    len = 1
    while n != 1:

        if n % 2 == 0:  # si el numero es par
            n //= 2
        else:
            n = n*3 + 1
        len += 1
    return len


for i in range(100000, 600000, 50000):
    secuencia = len_collatz(i)
    print(secuencia)
