data = [1, 3, 5, 2, 7, 4, 10]
print("\n")
print("-"*35)
print("Testing filter, map and reduce".center(35))
print("\n")
print("-"*35)

print("data ", data)

num_filter = []

for n in data:
    if n % 2 == 0:
        num_filter.append(n)


def is_even(n):
    return n % 2 == 0


num_filter = []

for n in data:
    if is_even(n):
        num_filter.append(n)

print("num_filter ", num_filter)

print("-"*35)
num_filter = list(filter(is_even, data))
print("using filter")
print(num_filter)

print("-"*35)
num_filter = list(filter(lambda n: n % 2 == 0, data))
print("using filter and lambda")
print(num_filter)
