from multiprocessing import Process, Queue
import time
import time_experiments as profile


def sum_in_range(from_limit, to_limit):
    sum = 0
    for n in range(from_limit, to_limit):
        sum += n

    return sum


def __sum_in_range__queue_worker(sum_from, sum_to, queue_connection):
    # do the work
    partial_sum = sum_in_range(sum_from, sum_to)
    # send the result to parent process via queue
    queue_connection.put(partial_sum)


def sum_in_range_process_queues(from_limit, to_limit, num_process):
    # mechanism IPC
    queue_connection = Queue()
    # distribuir la carga de trabajo
    size_chunk = (to_limit - from_limit) // num_process
    params = [{"sum_from": n * size_chunk,
               "sum_to": (n + 1)*size_chunk,
               "queue_connection": queue_connection} for n in range(num_process)
              ]
    params[-1]["sum_to"] = to_limit

    # crear los procesos hijos y asignarles las cargas de trabajo
    jobs = []
    for p in params:
        worker = Process(target=__sum_in_range__queue_worker, kwargs=p)
        worker.start()
        jobs.append(worker)

    # esperar a que los hijos terminen el trabajo asignado
    for j in jobs:
        j.join()

    #  y colectamos resultados parciales para obtener el resultado final
    total_sum = 0
    while queue_connection.empty() is False:
        total_sum += queue_connection.get()

    return total_sum


def main():

    print("\n")
    print("-"*60)
    print(" testing sum numbers with process and queues". center(60))
    print("-"*60)
    print("\n")

    from_limit = 0
    to_limit = int(1e7)
    num_process = 2

    # serial
    tic = time.time()
    result = sum_in_range(from_limit, to_limit)
    toc = time.time()
    print("sum serial : ", result)
    print("took time : ", toc-tic)

    print("-"*60)

    # suma concurrente con process y queues
    tic = time.time()
    result = sum_in_range_process_queues(from_limit, to_limit, num_process)
    toc = time.time()
    print(f"sum concurrent QUEUES with num_process {num_process} is:", result)
    print("      took time : ", toc-tic)

    print("-"*60)
    print("\n")


def perfilar():

    print("-"*30)
    print("queque")
    print("-"*30)
    num_process = 4

    params_profile = [{"from_limit": 0, "to_limit": limit, "num_process": num_process}
                      for limit in [int(1e4), int(1e5), int(1e6), int(1e7)]]

    profile.run_experiments(
        sum_in_range_process_queues, params_profile, 5, f"Suma Serial de {num_process} queues process", xlabel="procesos")


if __name__ == "__main__":
    perfilar()
