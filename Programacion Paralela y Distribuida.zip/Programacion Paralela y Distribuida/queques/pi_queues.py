from multiprocessing import Process, Queue
import time
import random
import math
import time_experiments as profile


def estimate_pi_serial(num_points):
    """

    """
    num_inside = 0

    for _ in range(num_points):
        x = random.random()
        y = random.random()
        if x**2 + y**2 <= 1.0:
            num_inside += 1

    aproximate_pi = 4*num_inside / num_points

    return aproximate_pi


def estimate_pi(from_limit, to_limit):
    num_inside = 0
    for _ in range(from_limit, to_limit):
        x = random.random()
        y = random.random()
        if x**2 + y**2 <= 1.0:
            num_inside += 1

    return num_inside


def __estimate_pi_worker(from_limit, to_limit, queue_connection):
    partial_pi = estimate_pi(from_limit, to_limit)
    queue_connection.put(partial_pi)


def estimate_pi_process_queues(from_limit, to_limit, num_process):
    # mechanism IPC
    queue_connection = Queue()
    # distribuir la carga de trabajo
    size_chunk = (to_limit - from_limit) // num_process
    params = [{"from_limit": n * size_chunk,
               "to_limit": (n + 1)*size_chunk,
               "queue_connection": queue_connection} for n in range(num_process)
              ]
    params[-1]["to_limit"] = to_limit

    # crear los procesos hijos y asinarles las cargas de trabajo
    # asignamos las cargas de trabajo
    jobs = []
    for p in params:
        worker = Process(target=__estimate_pi_worker, kwargs=p)
        worker.start()
        jobs.append(worker)

    # esperar a que los hijos envien los resultados parcial
    for j in jobs:
        j.join()

    area = 0
    while queue_connection.empty() is False:
        area += queue_connection.get()
    aproximate_pi = 4*area / to_limit

    return aproximate_pi


def tabla():
    from_limit = 0
    to_limit = 1000
    num_process = 4
    print("\n")
    print("-"*61)
    print("num".center(10), "|", " error".center(25), "|", "error".center(18))
    print("puntos".center(10), "|", "serial".center(
        25), "|", "concurrente_pipes".center(15))
    print("-"*61)
    for a in range(10):
        # serial
        result_serial = estimate_pi_serial(to_limit)
        # serial concurrent con process y pipes
        result_pipes = estimate_pi_process_queues(
            from_limit, to_limit, num_process)
        error_serial = abs((result_serial - math.pi)/math.pi)
        error_pipes = abs((result_pipes - math.pi)/math.pi)
        print("1e8".center(10), "|",
              f"{error_serial}".center(25), "|", f"{error_pipes}".center(15))


def main():
    from_limit = 0
    to_limit = 1000
    num_process = 4
    print("\n")
    print("-"*61)
    print("num".center(10), "|", " error".center(25), "|", "error".center(18))
    print("puntos".center(10), "|", "serial".center(
        25), "|", "concurrente_pipes".center(15))
    print("-"*61)
    for a in range(10):
        # serial
        result_serial = estimate_pi_serial(to_limit)
        # serial concurrent con process y pipes
        result_pipes = estimate_pi_process_queues(
            from_limit, to_limit, num_process)
        error_serial = abs((result_serial - math.pi)/math.pi)
        error_pipes = abs((result_pipes - math.pi)/math.pi)
        print("1e8".center(10), "|",
              f"{result_serial}".center(25), "|", f"{result_pipes}".center(15))


def perfilar():
    num_process = 4
    params_profile = [{"from_limit": 0, "to_limit": limit, "num_process": num_process}
                      for limit in range(int(1e8), int(10e8), int(1e8))]

    profile.run_experiments(estimate_pi_process_queues, params_profile, 10,
                            f"Estimate pi con {num_process} procesos", xlabel="procesos")


if __name__ == "__main__":
    main()
