from multiprocessing import Process, Pipe
import time
import time_experiments as profile
import random
import math


def estimate_pi_serial(num_points):
    """

    """
    num_inside = 0

    for _ in range(num_points):
        x = random.random()
        y = random.random()
        if x**2 + y**2 <= 1.0:
            num_inside += 1

    aproximate_pi = 4*num_inside / num_points

    return aproximate_pi


def estimate_pi(from_limit, to_limit):
    print(from_limit)
    print(to_limit)
    num_inside = 0
    for _ in range(from_limit, to_limit):
        x = random.random()
        y = random.random()
        if x**2 + y**2 <= 1.0:
            num_inside += 1

    return num_inside


def __estimate_pi_worker(from_limit, to_limit, child_pipe_connection):
    partial_pi = estimate_pi(from_limit, to_limit)
    child_pipe_connection.send(partial_pi)
    child_pipe_connection.close()


def estimate_pi_process_pipes(from_limit, to_limit, num_process):
    # distribuir la carga de trabajo
    size_chunk = (to_limit - from_limit) // num_process
    params = [{"from_limit": n * size_chunk,
               "to_limit": (n + 1)*size_chunk,
               **dict(zip(["parent_pipe_connection", "child_pipe_connection"], Pipe()))
               } for n in range(num_process)
              ]
    params[-1]["to_limit"] = to_limit

    # crear los procesos hijos y asinarles las cargas de trabajo
    for p in params:
        job = Process(target=__estimate_pi_worker, kwargs=filter(
            lambda item: item[0] != "parent_pipe_connection", p.items()))
        job.start()

    # esperar a que los hilos terminen el trabajo asignado
    total_aproximate = 0
    for j in params:
        total_aproximate += j["parent_pipe_connection"].recv()
    aproximate_pi = 4*total_aproximate / to_limit

    return aproximate_pi


def tabla():
    from_limit = 0
    to_limit = 1000
    num_process = 4
    print("\n")
    print("-"*61)
    print("num".center(10), "|", " error".center(25), "|", "error".center(18))
    print("puntos".center(10), "|", "serial".center(
        25), "|", "concurrente_pipes".center(15))
    print("-"*61)
    for a in range(10):
        # serial
        result_serial = estimate_pi_serial(to_limit)
        # serial concurrent con process y pipes
        result_pipes = estimate_pi_process_pipes(
            from_limit, to_limit, num_process)
        error_serial = abs((result_serial - math.pi)/math.pi)
        error_pipes = abs((result_pipes - math.pi)/math.pi)
        print("1e8".center(10), "|",
              f"{error_serial}".center(25), "|", f"{error_pipes}".center(15))


def main():
    num_process = 4
    params_profile = [{"from_limit": 0, "to_limit": limit, "num_process": num_process}
                      for limit in range(int(1e8), int(10e8), int(1e8))]

    profile.run_experiments(estimate_pi_process_pipes, params_profile, 10,
                            f"Estimate pi con {num_process} procesos", xlabel="procesos")


if __name__ == "__main__":
    tabla()
