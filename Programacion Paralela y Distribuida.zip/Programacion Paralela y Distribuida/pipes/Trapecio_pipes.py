import math
import time
import time_experiments as profile
from multiprocessing import Process, Pipe


def f(x):
    return 1.25*math.sin(x/2) + 3


def trapezoidal_integration(function_to_integrate, lower_limit, upper_limit, num_divisions):
    """
        Implementa la integracion por el metodo de los trapecios
        dada una funcion el area bajo la curva se aproxima dividiendo el
        intervalo de integracion en num_divisions y
        Args:
            function_to_integrate (function): la funcion escalar a integrar
            lower_limit (float): el limite inferior del intervalo de integracion
            upper_limit ([type]): el limite superior del intervalo de integracion
            num_divisions ([type]): el numero de divisiones a realizar
    Return (float): el valor de la aproximado de la integral """

    dx = (upper_limit - lower_limit) / num_divisions

    area = 0

    for n in range(1, num_divisions):
        area += function_to_integrate(lower_limit + n*dx)

    area = 0.5*function_to_integrate(lower_limit) + \
        area + 0.5*function_to_integrate(upper_limit)
    area *= dx

    return area


def __trapezoidal_integration_worker(function_to_integrate, from_limit, num_trapezoids, size_dx, child_pipe_connection):
    partial_area = 0

    for n in range(1, num_trapezoids):
        partial_area += function_to_integrate(from_limit + n*size_dx)

    partial_area = 0.5*function_to_integrate(from_limit) + partial_area + \
        0.5*function_to_integrate(from_limit + num_trapezoids*size_dx)
    partial_area *= size_dx

    child_pipe_connection.send(partial_area)
    child_pipe_connection.close()


def trapezoidal_integration_with_process_pipes(function_to_integrate, lower_limit, upper_limit, num_divisions, num_process):
    size_chunk_interval = (upper_limit - lower_limit) // num_process
    size_chunk_divisions = num_divisions // num_process
    size_dx = (upper_limit - lower_limit) / num_divisions
    # print("size_dx", size_dx)
    # print("size_chunk_divisions", size_chunk_divisions)
    # print("size_chunk_interval", size_chunk_interval)

    params = [{"function_to_integrate": function_to_integrate,
               "from_limit": n * size_chunk_divisions * size_dx + lower_limit,
               "num_trapezoids": size_chunk_divisions,
               "size_dx": size_dx,
               **dict(zip(["parent_pipe_connection", "child_pipe_connection"], Pipe()))
               } for n in range(num_process)
              ]
    params[-1]["num_trapezoids"] = size_chunk_divisions + \
        num_divisions % num_process

    # crear los procesos hijos y asinarles las cargas de trabajo
    for p in params:
        job = Process(target=__trapezoidal_integration_worker, kwargs=filter(
            lambda item: item[0] != "parent_pipe_connection", p.items()))
        job.start()

    area = 0
    for j in params:
        area += j["parent_pipe_connection"].recv()

    return area


def main():
    print("-"*40)
    print(" Integration with trapezoidal method".center(40))
    print("-"*40)

    lower_limit = 1
    upper_limit = 9
    num_divisions = 1000000

    value = trapezoidal_integration(f, lower_limit, upper_limit, num_divisions)
    print("Serial result: ", value)
    print("-"*20)

    num_process = 2
    value = trapezoidal_integration_with_process_pipes(
        f, lower_limit, upper_limit, num_divisions, num_process)
    print("Concurrent result Pipes: ", value)


def perfilar():
    print("-"*30)
    print("pipes")
    print("-"*30)
    num_process = 4

    params_profile = [{"function_to_integrate": f, "lower_limit": 1, "upper_limit": 9, "num_divisions": limit, "num_process": num_process}
                      for limit in [int(1e4), int(1e5), int(1e6), int(1e7)]]

    profile.run_experiments(
        trapezoidal_integration_with_process_pipes, params_profile, 5, f"Integral definida, método del trapecio con {num_process} pipes process", xlabel="procesos")


if __name__ == "__main__":
    perfilar()
