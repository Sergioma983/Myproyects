import matplotlib.pyplot as plt
import time
import time_experiments as profile
from multiprocessing import Process, Pipe


def table_relative_prime(size):
    tabla_primos = [[False]*size for _ in range(size)]

    for i in range(0, size):
        for j in range(0, size):
            tabla_primos[i][j] = is_relative_prime(i, j)

    return tabla_primos


def is_relative_prime(x, y):
    m = min(x, y) + 1

    for d in range(2, m):
        if x % d == 0 and y % d == 0:
            return False
    return True


def __chunk_table_primos_relativos_worker(from_row, to_row, size_row, child_connection):
    # crea y rellena los renglones de la tabla de primos

    num_rows = to_row - from_row

    sub_table = [[False]*size_row for _ in range(num_rows)]

    print("tabla: ", size_row)
    for i in range(0, num_rows):
        for j in range(0, size_row):
            sub_table[i][j] = is_relative_prime(i + from_row, j)

    child_connection.send(sub_table)
    child_connection.close()


def generate_table_primos_relativos_with_process_pipes(size_table, num_process):
    # distribuir la carga de trabajo entre los procesos
    size_chunk = size_table // num_process
    params_worker = [{"from_row": t * size_chunk,
                      "to_row": (t + 1) * size_chunk,
                      "size_row": size_table,
                      **dict(zip(["parent_connection", "child_connection"], Pipe()))
                      }for t in range(num_process)]

    params_worker[-1]["to_row"] = size_table

    # asignamos las cargas de trabajo
    for p in params_worker:
        p = Process(target=__chunk_table_primos_relativos_worker, kwargs=filter(
            lambda item: item[0] != "parent_connection", p.items()))
        p.start()

    # esperar a que los procesos terminen el trabajo asignado
    # y colectar resultados parciales para generar el resultado final

    # all_table =  [[False]*size_table for _ in range(size_table)]
    all_table = []
    for p in params_worker:
        sub_table = p["parent_connection"].recv()
        all_table.extend(sub_table)

        # from_rom = p["from_row"]
        # to_row = p["to_row"]
        # num_rows = p["to_row"] - p["from_row"]
        # for i in range (num_rows):
        #     for j in range(size_table):
        #         all_table[i][j] = sub_table[i-num_rows][j]

    return all_table


def main():
    num_process = 2
    # params_profile= [
    #                 {"size_table":size,"num_threads":num_threads}
    #                 for size in range(100,700,70)
    #                 ]
    # profile.run_experiments(generate_table_primos_relativos_with_threads,params_profile, 1, "Collatz con 2 hilos")

    size = int(1e3)
    print("-"*50)
    tic = time.time()
    tabla_primos1 = table_relative_prime(size)
    toc = time.time()
    print("SERIAL took time: ", toc-tic)

    plt.matshow(tabla_primos1)
    plt.show()
    toc = time.time()
    print("plot took time: ", toc-tic)

    print("\n")
    print("-"*50)
    tic = time.time()
    tabla_primos2 = generate_table_primos_relativos_with_process_pipes(
        size, num_process)
    toc = time.time()
    print("CONCURRENT table took time: ", toc-tic)

    plt.matshow(tabla_primos2)
    plt.show()
    toc = time.time()
    print("plot took time: ", toc-tic)


def perfilar():
    print("-"*30)
    print("pipes")
    print("-"*30)
    num_process = 4
    params_profile = [{"size_table": limit, "num_process": num_process}
                      for limit in [int(1e3), int(1e4), int(1e5), int(1e6)]]

    profile.run_experiments(generate_table_primos_relativos_with_process_pipes, params_profile, 5,
                            f"Primos relativos con {num_process} procesos pipes", xlabel="procesos")


if __name__ == "__main__":
    main()
