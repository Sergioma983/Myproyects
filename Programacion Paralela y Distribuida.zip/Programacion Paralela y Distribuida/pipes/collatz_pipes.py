from multiprocessing import Process, Pipe
import time
from matplotlib import pyplot as plt
import time_experiments as profile


def len_collatz(n):
    """[summary]
    Regresa la longitud de la sucesion de collatz para el numero n

    la sucesion de collatz de numero

    Args:
        num (int): [el numero base para iniciar la sucesion de collatz]
    """
    if n < 2:
        return n

    len = 1
    while n != 1:
        if n % 2 == 0:  # si el numero es par
            n //= 2
        else:
            n = n*3 + 1
        len += 1

    return len


def generate_table_collatz(from_limit, to_limit):
    table = []
    for n in range(from_limit, to_limit):
        table.append(len_collatz(n))
    return table


def __table_collatz_worker(from_limit, to_limit, child_pipe_connection):
    partial_collatz = generate_table_collatz(from_limit, to_limit)
    child_pipe_connection.send(partial_collatz)
    child_pipe_connection.close()


def collatz_process_pipes(size_table, num_process):
    orbits = [0]*(size_table + 2)
    # distribuir la carga de trabajo
    size_chunk = (size_table) // num_process
    params = [{"from_limit": n * size_chunk,
               "to_limit": (n + 1)*size_chunk,
               **dict(zip(["parent_pipe_connection", "child_pipe_connection"], Pipe()))
               } for n in range(num_process)
              ]
    params[-1]["to_limit"] = size_table
    # crear los procesos hijos y asinarles las cargas de trabajo
    for p in params:
        job = Process(target=__table_collatz_worker, kwargs=filter(
            lambda item: item[0] != "parent_pipe_connection", p.items()))
        job.start()

    # esperar a que los hilos terminen el trabajo asignado
    orbits = []
    for j in params:
        list_partial = j["parent_pipe_connection"].recv()
        orbits.extend(list_partial)

    # colectar los resultados parciales para obtener el resultado total
    #   esta parte es trivial para Collatz por que vas a regresar
    #   el arreglo que rellenan los hilos con las orbitas
    #
    return orbits


def main():
    from_limit = 0
    to_limit = 1200
    number_process = 2

    result = generate_table_collatz(from_limit, to_limit)
    print("resultado: ", len(result))
    plt.scatter(range(to_limit), result)
    plt.title("Collatz with process")
    plt.xlabel("n")
    plt.ylabel("len collatz")
    plt.show()

    result = collatz_process_pipes(to_limit, number_process)
    print("resultado: ", len(result))
    plt.scatter(range(to_limit), result)
    plt.title("Collatz with process")
    plt.xlabel("n")
    plt.ylabel("len collatz")
    plt.show()


def perfilar():
    print("-"*30)
    print("pipes")
    print("-"*30)
    num_process = 4
    params_profile = [{"size_table": limit, "num_process": num_process}
                      for limit in [int(1e3), int(1e4), int(1e5), int(1e6)]]

    profile.run_experiments(collatz_process_pipes, params_profile, 5,
                            f"Collatz con {num_process} procesos pipes", xlabel="procesos")


if __name__ == "__main__":
    main()
