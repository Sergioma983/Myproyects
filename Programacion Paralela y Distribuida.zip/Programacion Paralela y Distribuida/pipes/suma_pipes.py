from multiprocessing import Process, Pipe
import time
import time_experiments as profile


def sum_in_range(from_limit, to_limit):
    sum = 0
    for n in range(from_limit, to_limit):
        sum += n
    return sum


def __sum_in_range_worker(sum_from, sum_to, child_pipe_connection):
    partial_sum = sum_in_range(sum_from, sum_to)
    child_pipe_connection.send(partial_sum)
    child_pipe_connection.close()


def sum_in_range_process_pipes(sum_from, sum_to, num_process):
    # distribuir la carga de trabajo
    size_chunk = (sum_to - sum_from) // num_process
    params = [{"sum_from": n * size_chunk,
               "sum_to": (n + 1)*size_chunk,
               **dict(zip(["parent_pipe_connection", "child_pipe_connection"], Pipe()))
               } for n in range(num_process)
              ]
    params[-1]["sum_to"] = sum_to
    # crear los procesos hijos y asinarles las cargas de trabajo
    for p in params:
        job = Process(target=__sum_in_range_worker, kwargs=filter(
            lambda item: item[0] != "parent_pipe_connection", p.items()))
        job.start()

    total_sum = 0
    for j in params:
        total_sum += j["parent_pipe_connection"].recv()

    return total_sum


def main1():
    from_limit = 0
    to_limit = int(1e7)
    num_process = 4
    # serial concurrent con process y pipes
    tic = time.time()
    result = sum_in_range_process_pipes(from_limit, to_limit, num_process)
    toc = time.time()
    print("-"*10)
    print("Tiempo", toc-tic)
    print(f"sum concurrent with pipes num_process {num_process} is: ", result)
    print("-"*10)


def main():
    for num_process in range(1, 17):
        params_profile = [{"sum_from": 0, "sum_to": limit, "num_process": num_process}
                          for limit in [int(1e6), int(1e7), int(1e8), int(1e9), int(1e10), int(1e11), int(1e12)]]

        profile.run_experiments(
            sum_in_range_process_pipes, params_profile, 10, f"Suma de {num_process} procesos", xlabel="procesos")


def perfilar():

    print("-"*30)
    print("queque")
    print("-"*30)
    num_process = 4

    params_profile = [{"sum_from": 0, "sum_to": limit, "num_process": num_process}
                      for limit in [int(1e4), int(1e5), int(1e6), int(1e7)]]

    profile.run_experiments(sum_in_range_process_pipes, params_profile, 5,
                            f"Suma Serial de {num_process} queues process", xlabel="procesos")


if __name__ == "__main__":
    perfilar()
