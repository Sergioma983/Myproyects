# -*- coding: utf-8 -*-
"""primos_colas
"""

import matplotlib.pyplot as plt
import time
#import time_experiments as profile
from multiprocessing import Process, Queue


def table_relative_prime(size):
    tabla_primos = [[False]*size for _ in range(size)]

    for i in range(0, size):
        for j in range(0, size):
            tabla_primos[i][j] = is_relative_prime(i, j)

    return tabla_primos


def is_relative_prime(x, y):
    m = min(x, y) + 1
    if x <= 2 or y <= 2:
        return False

    for d in range(2, m):
        if x % d == 0 and y % d == 0:
            return False

    return True


def __chunk_table_primos_relativos_worker(from_row, to_row, size_row):
    # crea y rellena los renglones de la tabla de primos
    # print("init ", from_row, to_row)
    # tic = time.time()
    # if from_row == 0:
    #    time.sleep(5)

    num_rows = to_row - from_row
    sub_table = [[False]*size_row for _ in range(num_rows)]
    for i in range(0, num_rows):
        for j in range(0, size_row):
            sub_table[i][j] = is_relative_prime(i + from_row, j)

    return sub_table


def worker(input, output):
    for from_row, to_row, size_row in iter(input.get, 'STOP'):
        result = __chunk_table_primos_relativos_worker(
            from_row, to_row, size_row)
        output.put((from_row, to_row, result))


def generate_table_primos_relativos_queue_dynamic_jobs(size_table, num_process, num_splits):
    # crear las cargas de trabajo
    size_chunk = size_table // num_splits
    params_job = [(t * size_chunk,
                   (t + 1) * size_chunk,
                   size_table
                   )for t in range(num_splits)]

    # Create queues
    task_queue = Queue()
    done_queue = Queue()

    # Start worker processes
    # create pool process
    for i in range(num_process):
        Process(target=worker, args=(task_queue, done_queue)).start()

    # Submit tasks
    for task in params_job:
        task_queue.put(task)

    # esperar a que los procesos terminen el trabajo asignado
    # y colectar resultados parciales para generar el resultado final
    all_table = [0]*size_table

    for p in range(num_splits):
        (from_index, to_index, sub_table) = done_queue.get()
        all_table[from_index:to_index] = sub_table

    # Tell child processes to stop
    # free pool process
    for i in range(num_process):
        task_queue.put('STOP')

    return all_table


def main():
    num_process = 2
    num_split = 10
    # params_profile= [
    #                 {"size_table":size,
    #                 "num_process":num_process,
    #                 "child_queue_connection" : ipc_queue

    #                 }
    #                     for size in range(100,501,100)
    #                     for num_process in range(1,5)
    #                 ]

    #profile.run_experiments(generate_table_primos_relativos_with_queue, params_profile, 1, "Relative Primes with Process - Pipes")

    size = 250

    # print("-"*50)
    #tic = time.time()
    #tabla_primos = table_relative_prime(size)
    #toc = time.time()
    #print("SERIAL took time: ", toc-tic)

    print("\n")
    print("-"*50)
    tic = time.time()
    tabla_primos = generate_table_primos_relativos_queue_dynamic_jobs(
        size, num_process, num_split)
    toc = time.time()
    print("CONCURRENT table took time: ", toc-tic)
    print("-"*50)

    plt.matshow(tabla_primos)
    plt.title("CONCURRENT")
    plt.show()
    toc = time.time()


if __name__ == "__main__":
    main()
