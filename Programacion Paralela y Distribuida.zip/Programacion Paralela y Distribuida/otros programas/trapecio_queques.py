from multiprocessing import Process, Queue
import time
import time_experiments as profile
import numpy as np


def fx(x): return 1.25*np.sin(x/2)+3


def trapecio(from_limit, to_limit):
    a = 1
    b = 9
    size_division = (b-a) / to_limit

    partial = 0

    x = a
    for _ in range(from_limit, to_limit):
        partial += fx(x)
        x += size_division

    area = size_division * partial
    return area


def __trapecio_worker(from_limit, to_limit, queue_connection):
    partial_sum = trapecio(from_limit, to_limit)
    queue_connection.put(partial_sum)


def trapecio_process_pipes(from_limit, to_limit, num_process):
    # mechanism IPC
    queue_connection = Queue()
    # distribuir la carga de trabajo
    size_chunk = (to_limit - from_limit) // num_process
    params = [{"from_limit": n * size_chunk,
               "to_limit": (n + 1)*size_chunk,
               "queue_connection": queue_connection} for n in range(num_process)
              ]
    params[-1]["to_limit"] = to_limit
    # crear los procesos hijos y asinarles las cargas de trabajo
    for p in params:
        worker = Process(target=__trapecio_worker, kwargs=p)
        worker.start()

    # esperar a que los hijos terminen el trabajo asignado
    for j in params:
        j.join()

    sum_process_trapecio = 0
    while queue_connection.empty() is False:
        sum_process_trapecio += queue_connection.get()

    return sum_process_trapecio


def main():
    from_limit = 1
    to_limit = 9
    num_process = 2
    # serial
    tic = time.time()
    result = trapecio(from_limit, to_limit)
    toc = time.time()
    print("-"*10)
    print("Tiempo: ", toc-tic)
    print("trapecio serial: ", result)
    print("-"*10)
    # serial concurrent con process y pipes
    tic = time.time()
    result = trapecio_process_pipes(from_limit, to_limit, num_process)
    toc = time.time()
    print("-"*10)
    print("Tiempo", toc-tic)
    print(f"trapecio concurrent with num_process {num_process} is: ", result)
    print("-"*10)


if __name__ == "__main__":
    main()
