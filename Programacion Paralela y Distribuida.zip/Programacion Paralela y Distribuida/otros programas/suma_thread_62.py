from threading import Thread
from time import sleep

import time_experiments as profile
import time

max_num_threads = 10
partial_results = [0] * max_num_threads

# implementacion serial de la suma de numeros


def sum_in_range(lower_limit, upper_limit):
    sum = 0
    for n in range(lower_limit, upper_limit+1):
        sum += n
    return sum


def __sum_in_range_worker(lower_limit, upper_limit, index_result):
    partial_results[index_result] = sum_in_range(lower_limit, upper_limit-1)

# implementacion con hilos de la suma de numeros


def sum_in_range_with_threads(lower_limit, upper_limit, num_threads):
    num_threads = max(num_threads, max_num_threads)

    # distribuir la carga de trabajo entre los hilos
    size_chunk = (upper_limit - lower_limit) // num_threads
    params_sum = [{"lower_limit": t * size_chunk,
                   "upper_limit": (t + 1) * size_chunk,
                   "index_result": t
                   } for t in range(num_threads)]
    params_sum[-1]["upper_limit"] = upper_limit+1

    # crear los hilos y asignarlas las cargas de trabajo
    workers = []
    for p in params_sum:
        t = Thread(target=__sum_in_range_worker,  kwargs=p)
        t.start()
        workers.append(t)

    # esperar que los hilos terminen el trabajo asignado
    for t in workers:
        t.join()

    # colectar los resultados parciales para obtener el resultado
    total_sum = 0
    for value in partial_results:
        total_sum += value

    return total_sum


if __name__ == "__main__":

    lower_limit = 0
    upper_limit = int(1e7)
    process = 4

    tic = time.time()
    result = sum_in_range_with_threads(lower_limit, upper_limit, process)
    toc = time.time()
    print("-"*10)
    print("Tiempo", toc-tic)
    print(f"sum concurrent with _threads {process} is: ", result)
    print("-"*10)
