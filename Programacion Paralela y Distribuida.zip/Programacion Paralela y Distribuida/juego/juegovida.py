from matplotlib import pyplot as plt

"""
Implementa el juego de la vida
"""


def initialize_world(size, seeds):
    """
    inicializa el tablero del juego de la vida
    Args:
        size (int): el tamaño del tablero
        seeds ( list[(x,y)] ): las celdas vivas para inicializar el mundo
    """
    world = [[0]*size for _ in range(size)]

    for (x, y) in seeds:
        world[x][y] = 1

    return world


def cuenta_vecinos1(x, y):
    for i in range(0, x):
        for j in range(0, y):
            vecindad = world[(i-1) % x, (y-1) % y] + \
                world[(i) % x, (y-1) % y] + \
                world[(i+1) % x, (y-1) % y] + \
                world[(i-1) % x, (y) % y] + \
                world[(i+1) % x, (y) % y] + \
                world[(i-1) % x, (y+1) % y] + \
                world[(i) % x, (y+1) % y] + \
                world[(i+1) % x, (y+1) % y]


seeds = [(3, 3), (2, 4), (4, 4), (4, 2)]
size = 8

world = initialize_world(size, seeds)

plt.matshow(world)
plt.show()


def evolve():
    # contar el numero de vecinos que tiene vivos para cada celda en el mundo
    for i in range(size):  # recorrer el mundo
        for j in range(size):
            # para cada celda en el mundo contar sus vecinos
            num_vecinos = cuenta_vecinos(x, y)
            # si celda (x, y) esta viva y num es 2 o 3
            if world2[y][x] == 1 and num_vecinos == 2 or num_vecinos == 3:
                world2[y][x] = 1

                #  entonces sigue viva
                # caso contrario muere
                #
                # si celda (x,y) esta muerta y num_vecinos es 3
                # entonces vive
