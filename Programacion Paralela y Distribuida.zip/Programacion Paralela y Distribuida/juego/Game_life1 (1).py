"""
Implementa el juego de la vida 
Se trata de un juego de cero jugadores, lo que quiere decir que su evolución está 
determinada por el estado inicial y no necesita ninguna entrada de datos posterior. 

El "tablero de juego" es una malla plana formada por cuadrados (las "células") que se extiende por el infinito
en todas las direcciones. 

Por tanto, cada célula tiene 8 células "vecinas", que son las que están próximas a ella, 
incluidas las diagonales. 

Las células tienen dos estados: están "vivas" o "muertas" (o "encendidas" y "apagadas"). 

El estado de las células evoluciona a lo largo de unidades de tiempo discretas (se podría decir que por turnos). 

El estado de todas las células se tiene en cuenta para calcular el estado de las mismas al turno siguiente. 

Todas las células se actualizan simultáneamente en cada turno, siguiendo estas reglas:

    Una célula muerta con exactamente 3 células vecinas vivas "nace" (es decir, al turno siguiente estará viva).
    Una célula viva con 2 o 3 células vecinas vivas sigue viva, en otro caso muere (por "soledad" o "superpoblación").
"""
import random as rnd
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import time


def count_vecinos(x, y, world):
    size = len(world)
    num_vivas = 0
    for row in range(y-1, y+2):
        for col in range(x-1, x+2):
            num_vivas += world[row % size][col % size]

    num_vivas -= world[y][x]

    return num_vivas


def initialize_world(size, num_seeds):
    """
    Inicializa el tablero del juego de la vida con num_seeds celdas vivas 
    colocadas aleatoriamente en el tablero

    Args:
        size ([type]): [description]
        num_seeds ([type]): [description]
    """
    world = [[0] * size for _ in range(size)]

    for _ in range(num_seeds):
        world[rnd.randrange(size)][rnd.randrange(size)] = 1

    return world


def initialize_world__(size, seeds):
    """
    Inicializa el tablero del juego de la vida

    Args:
        size ([arreglo]): [Tamaño del tablero]
        seeds (list(x,y)): las celdas vivas para iniciar el mundo  
    """
    world = [[0] * size for _ in range(size)]

    p = size//2
    for (x, y) in seeds:
        world[p+y][p+x] = 1

    return world


def evolve_world(world):
    """
    Se calcularan el numero de vecinos por cada celda viva.
    Args:
        world ([arreglo]): [Coordenadas donde se contaran los vecinos]

    Returns:
        [int]: [Mostrara si la celda vive o muere]
    """

    size = len(world)
    world2 = [[0] * size for _ in range(size)]

    for x in range(size):  # recorrer el mundo
        for y in range(size):

            # para cada celda en el mundo contar sus vecinos
            num_vecinos = count_vecinos(x, y, world)
            # si celda (x,y) esta viva y num_vecinos es 2 o 3
            # entonces sigue viva

            if world[y][x] == 1:
                if num_vecinos == 2 or num_vecinos == 3:
                    world2[y][x] = 1
            # caso contrario muere
                else:
                    world2[y][x] = 0

            # si celda (x,y) esta muerta y num__vecinos es 3
            # entonces vive
            if world[y][x] == 0 and num_vecinos == 3:
                world2[y][x] = 1

    return world2


def update(d):
    global world

    # actualizo el estado del mundo
    tic = time.time()
    world = evolve_world(world)
    toc = time.time()
    print(toc-tic)
    # refresh de la vista en pantalla
    mat.set_data(world)
    return mat


seeds = [(5, 5), (5, 4), (4, 4), (5, 6), (6, 5), (7, 1), (2, 3), (4, 5)]
size = 800
world = initialize_world__(size, seeds)

fig, ax = plt.subplots()
ax.axis('off')
mat = ax.matshow(world)

ani = animation.FuncAnimation(
    fig, update, frames=100, interval=50, repeat=True)

plt.show()
