import numpy as np

seria = [0.035002708, 0.033007383, 0.034992695, 0.032007933, 0.03200531, 0.029005527, 0.029005289, 0.029006243,
         0.028005838, 0.028004408]
pools = [2.211552382, 2.268569469, 2.401600838, 2.32658124, 2.333584785, 2.308581114, 2.393602848, 2.382572174,
         2.326575756, 2.758691788]
queues = [3.799698114, 3.745689869, 3.7536896, 3.631658335, 3.6106534, 3.680653142, 4.644659061, 4.741686585,
          4.64165761, 3.618659973, ]

print("\n")
print("\n")
print("-"*60)
print("Queues y Pool".center(20), "Queues".center(20),
      "Serial".center(20))
print("-"*60)
print("2.211552382".center(20), "3.799698114".center(20),
      "0.035002708".center(20))
print("2.268569469".center(20), "3.745689869".center(20),
      "0.033007383".center(20))
print("2.401600838".center(20), "3.7536896".center(20),
      "0.034992695".center(20))
print("2.32658124".center(20), "3.631658335".center(20),
      "0.032007933".center(20))
print("2.333584785".center(20), "3.6106534".center(20),
      "0.03200531".center(20))
print("2.308581114".center(20), "3.680653142".center(20),
      "0.029005527".center(20))
print("2.393602848".center(20), "4.644659061".center(20),
      "0.029005289".center(20))
print("2.382572174".center(20), "4.741686585".center(20),
      "0.029006243".center(20))
print("2.326575756".center(20), "4.64165761".center(20),
      "0.028005838".center(20))
print("2.758691788".center(20), "3.618659973".center(20),
      "0.028004408".center(20))
print("-"*60)
print("\n")
print("\n")


serial_min = np.min(seria)
serial_max = np.max(seria)
queues_min = np.min(queues)
queues_max = np.max(queues)
pools_min = np.min(pools)
pools_max = np.max(pools)


for x in seria:
    sum = + x
    serial_prom = sum/10
for x in queues:
    sum = + x
    queues_prom = sum/10
for x in pools:
    sum = + x
    pools_prom = sum/10

print("\n")
print("\n")
print("-"*80)
print("Version".center(20), "Minimo".center(20),
      "Maximo".center(20), "Promedio".center(20))
print("-"*80)
print("Serial".center(20), format(serial_min).center(20), format(
    serial_max).center(20), format(round(serial_prom, 10)).center(20))
print("Queues".center(20), format(queues_min).center(20), format(
    queues_max).center(20), format(queues_prom).center(20))
print("Queues y Pool".center(20), format(pools_min).center(20), format(
    pools_max).center(20), format(pools_prom).center(20))
print("-"*80)
print("\n")
print("\n")
