import multiprocessing
import matplotlib.pyplot as plt
import ctypes
import time
import sys
import numpy as np

tableData = []


def is_relative_prime(x, y):
    """[summary]
        Dos numeros x, y son primos relativos el unico divisor comun es el 1 
    Args:
        x ([int]): [description]
        y ([int]): [description]
    """
    m = min(x, y) + 1

    for d in range(2, m):
        if x % d == 0 and y % d == 0:
            return 0
    return 1


def relativePrimesInRange_sharedMemory(fromRow, toRow, size_table, shared_array):
    shared_array = np.frombuffer(shared_array.get_obj())
    table = shared_array.reshape((size_table, size_table))

    num_rows = toRow - fromRow
    for ii in range(0, num_rows):
        for jj in range(0, size_table):
            shared_array[ii][jj] = is_relative_prime(ii + fromRow, jj)

    return


def relativePrimes_Parallel_Ver3(size, numProcess):
    # setup shared memory
    shared_array = multiprocessing.Array(ctypes.c_double, size*size)

    # setup the subtask to assing
    numChunks = numProcess
    sizeChunk = (size) // numChunks

    fromLimits = []
    for ii in range(numChunks):
        print(ii)
        # setup the chunk of data to work for each process
        fromLimit = ii*sizeChunk
        fromLimits.append(fromLimit)

    jobs = []
    for limit in fromLimits:
        p = multiprocessing.Process(
            target=relativePrimesInRange_sharedMemory, args=(limit, sizeChunk, size, shared_array))
        p.start()
        jobs.append(p)

    # waiting for all works is done

    for j in jobs:
        j.join()

    return[shared_array]


"""
    Testing the code
"""


def main():

    size = int(1e3)

    table_primes = tableData

    tic = time.time()
    table_primes = relativePrimes_Parallel_Ver3(
        size, numProcess=multiprocessing.cpu_count())
    toc = time.time()
    print("Process time for relativePrimes_Parallel_Ver3: {0}".format(toc-tic))
    print("".center(50, "-"))

    plt.matshow(table_primes)
    plt.show()


if __name__ == "__main__":
    main()
