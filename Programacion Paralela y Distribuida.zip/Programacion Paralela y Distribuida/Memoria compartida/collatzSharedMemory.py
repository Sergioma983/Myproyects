import multiprocessing
import ctypes
import matplotlib.pyplot as plt
import time


# Global variable to allocate the results
globalNumbers = []
globalLenghts = []


def lengthAndMaximumInCollatzSequence(n):
    number = n
    length = 1
    maxValue = n

    while(n > 1):
        if n % 2 == 0:
            n /= 2
        else:
            n = 3*n + 1

        if n > maxValue:
            maxValue = n
        length += 1

    return number, length, maxValue


def computeCollatz_Serial(toLimit):

    numbers = []
    lengths = []

    ii = 3
    while ii <= toLimit:
        num, len, maxVal = lengthAndMaximumInCollatzSequence(ii)
        numbers.append(ii)
        lengths.append(len)

        ii += 1

    return [numbers, lengths]


def CollatzSequenceInRange_sharedMemory(fromNumber, sizeChunk, shared_array_numbers, shared_array_lengths):
    print("this is fromNumber: ", fromNumber)
    print("-------")
    print("this is sizeChunk: ", sizeChunk)

    ii = fromNumber
    toNumber = fromNumber + sizeChunk

    print("this is toNumber: ", toNumber)

    while ii < toNumber:
        n, l, m = lengthAndMaximumInCollatzSequence(ii)
        shared_array_numbers[ii] = n
        shared_array_lengths[ii] = l
        ii += 1

    return


def computeCollatz_Palallel_Ver3(toLimit, numProcess):
    # setup shared memory
    shared_array_lenghts = multiprocessing.Array(ctypes.c_double, toLimit+3)
    shared_array_numbers = multiprocessing.Array(ctypes.c_double, toLimit+3)

    # setup the subtask to assign
    numChunks = numProcess
    sizeChunk = int(toLimit / numChunks)

    fromLimits = []
    for ii in range(numChunks):
        # setup the chunk of data to work for each process
        fromLimit = ii*sizeChunk + 3
        fromLimits.append(fromLimit)

    jobs = []
    for limit in fromLimits:
        p = multiprocessing.Process(target=CollatzSequenceInRange_sharedMemory, args=(
            limit, sizeChunk, shared_array_lenghts, shared_array_numbers))
        p.start()
        jobs.append(p)

    # waiting for all works is done
    for j in jobs:
        j.join()

    return [shared_array_numbers, shared_array_lenghts]


"""
    Testing the code
"""


def main():
    print("".center(50, "#"))
    print(" Collatz Sequence Benchmark".center(50, "#"))
    print("".center(50, "#"))

    limitSupCollatz = int(1e3)  # int(1e6)

    numbers = globalNumbers
    lengths = globalLenghts

    tic = time.time()
    [numbers, lengths] = computeCollatz_Palallel_Ver3(
        toLimit=limitSupCollatz, numProcess=multiprocessing.cpu_count())
    toc = time.time()
    print(
        "Process  time for computeCollatz_Palallel_Ver3: {0}".format(toc-tic))
    print("".center(50, "-"))

    # Plot
    colors = (0.6, 0.6, 0.6)
    plt.scatter(numbers, lengths,  c=colors)
    plt.title('Lengths of Collatz sequence')
    plt.xlabel('Numbers')
    plt.ylabel('Lengths')
    plt.show()


if __name__ == "__main__":
    main()
