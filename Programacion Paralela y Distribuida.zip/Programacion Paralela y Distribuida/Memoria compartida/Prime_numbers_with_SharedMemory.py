import ctypes
import multiprocessing
from time import time
import numpy as np
from matplotlib import pyplot as plt

###################################################################


def is_relative_prime(x, y):

    m = min(x, y) + 1

    for d in range(2, m):
        if x % d == 0 and y % d == 0:
            return 0
    return 1

###################################################################


def worker_relative_prime(from_row, to_row, size_row, tabla):
    tabla = np.frombuffer(tabla.get_obj())
    table = tabla.reshape((size_row, size_row))

    for i in range(from_row, to_row):
        for j in range(0, size_row):
            table[i][j] = is_relative_prime(i, j)

###################################################################


def threads_primos_relativos(size_table, num_process):

    tabla = multiprocessing.Array(ctypes.c_double, size_table*size_table)

    size_chunk = (size_table) // num_process

    params_worker = [{"from_row":  t * size_chunk,
                      "to_row":   (t+1) * size_chunk,
                      "size_row":  size_table
                      } for t in range(num_process)]

    params_worker[-1]["from_row"] = params_worker[-2]["to_row"]
    params_worker[-1]["to_row"] = size_table

    workers = []
    for arg in params_worker:
        p = multiprocessing.Process(target=worker_relative_prime, args=(
            arg["from_row"], arg["to_row"], arg["size_row"], tabla))
        p.start()
        workers.append(p)

    for p in workers:
        p.join()

###################################################################


if __name__ == "__main__":

    size_table = 100
    num_process = 4
    temp = [[0]*size_table]*size_table

    print("*"*40)
    print("Version Con Shared Memory".center(40))
    tic = time()
    table = threads_primos_relativos(size_table, num_process)
    toc = time()
    print("\nEl Tiempo fue de: ", toc-tic)

    plt.matshow(table)
    plt.show()
