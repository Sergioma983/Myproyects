"""
Implementa el juego de la vida
Se trata de un juego de cero jugadores, lo que quiere decir que su evolución está
determinada por el estado inicial y no necesita ninguna entrada de datos posterior.

El "tablero de juego" es una malla plana formada por cuadrados (las "células") que se extiende por el infinito
en todas las direcciones.

Por tanto, cada célula tiene 8 células "vecinas", que son las que están próximas a ella,
incluidas las diagonales.

Las células tienen dos estados: están "vivas" o "muertas" (o "encendidas" y "apagadas").

El estado de las células evoluciona a lo largo de unidades de tiempo discretas (se podría decir que por turnos).

El estado de todas las células se tiene en cuenta para calcular el estado de las mismas al turno siguiente.

Todas las células se actualizan simultáneamente en cada turno, siguiendo estas reglas:

    Una célula muerta con exactamente 3 células vecinas vivas "nace" (es decir, al turno siguiente estará viva).
    Una célula viva con 2 o 3 células vecinas vivas sigue viva, en otro caso muere (por "soledad" o "superpoblación").
"""

from multiprocessing import Process, Queue
import random as rnd
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import time

world = []
mat = None

fig, ax = plt.subplots()
ax.axis('off')


def count_vecinos(x, y, world):
    size = len(world)
    num_vivas = 0
    for row in range(y-1, y+2):
        for col in range(x-1, x+2):
            num_vivas += world[row % size][col % size]

    num_vivas -= world[y][x]

    return num_vivas


def initialize_world(size, num_seeds):
    """
    Inicializa el tablero del juego de la vida con num_seeds celdas vivas
    colocadas aleatoriamente en el tablero

    Args:
        size ([type]): [description]
        num_seeds ([type]): [description]
    """
    world = [[0] * size for _ in range(size)]

    for _ in range(num_seeds):
        world[rnd.randrange(size)][rnd.randrange(size)] = 1

    return world


def initialize_world__(size, seeds):
    """
    Inicializa el tablero del juego de la vida

    Args:
        size ([arreglo]): [Tamaño del tablero]
        seeds (list(x,y)): las celdas vivas para iniciar el mundo
    """
    global world

    world = [[0] * size for _ in range(size)]

    p = size // 2
    for (x, y) in seeds:
        world[p+y][p+x] = 1

    return world


def evolve_world(world):
    """
    Se calcularan el numero de vecinos por cada celda viva.
    Args:
        world ([arreglo]): [Coordenadas donde se contaran los vecinos]

    Returns:
        [int]: [Mostrara si la celda vive o muere]
    """

    size = len(world)
    world2 = [[0] * size for _ in range(size)]

    for x in range(size):  # recorrer el mundo
        for y in range(size):

            # para cada celda en el mundo contar sus vecinos
            num_vecinos = count_vecinos(x, y, world)
            # si celda (x,y) esta viva y num_vecinos es 2 o 3
            # entonces sigue viva

            if world[y][x] == 1:
                if num_vecinos == 2 or num_vecinos == 3:
                    world2[y][x] = 1
            # caso contrario muere
                else:
                    world2[y][x] = 0

            # si celda (x,y) esta muerta y num__vecinos es 3
            # entonces vive
            if world[y][x] == 0 and num_vecinos == 3:
                world2[y][x] = 1

    return world2


def __evolve_world_worker(from_row, to_row, world):

    size_rows = to_row - from_row
    size_columns = len(world[0])
    world2 = [[0] * size_columns for _ in range(size_rows)]

    for y in range(size_rows):  # recorrer el mundo
        for x in range(size_columns):

            # para cada celda en el mundo contar sus vecinos
            num_vecinos = count_vecinos(x, y+from_row, world)
            # si celda (x,y) esta viva y num_vecinos es 2 o 3
            # entonces sigue viva

            if world[y+from_row][x] == 1:
                if num_vecinos == 2 or num_vecinos == 3:
                    world2[y][x] = 1
            # caso contrario muere
                else:
                    world2[y][x] = 0

            # si celda (x,y) esta muerta y num__vecinos es 3
            # entonces vive
            if world[y+from_row][x] == 0 and num_vecinos == 3:
                world2[y][x] = 1
    return(world2)


def _worker_(input, output):
    for from_row, to_row, size_row in iter(input.get, 'STOP'):
        result = __evolve_world_worker(
            from_row, to_row, size_row)
        output.put((from_row, to_row, result))


def evolve_world_process_dynamic_jobs(world, num_process, num_splits):
    # crear las cargas de trabajo
    size = len(world)

    size_chunk = size // num_splits
    params_job = [(t * size_chunk,
                   (t+1) * size_chunk,
                   world)for t in range(num_splits)]

    # Create queues
    task_queue = Queue()
    done_queue = Queue()

    # Start worker processes
    # create pool process
    for i in range(num_process):
        Process(target=_worker_, args=(task_queue, done_queue)).start()

    # Submit tasks
    for task in params_job:
        task_queue.put(task)

    # esperar a que los procesos terminen el trabajo asignado
    # y colectar resultados parciales para generar el resultado final
    all_world = [0] * size

    for p in range(num_splits):
        from_index, to_index, partial_table = done_queue.get()
        all_world[from_index:to_index] = partial_table

    # Tell child processes to stop
    # free pool process
    for i in range(num_process):
        task_queue.put('STOP')

    return all_world


def update(d):
    global world
    global mat
    times = []

    # actualizo el estado del mundo
    tic = time.time()
    world = evolve_world_process_dynamic_jobs(
        world, num_process=2, num_splits=10)
    toc = time.time()
    print(toc-tic)

    # refresh de la vista en pantalla
    mat.set_data(world)
    return mat


def main():
    global world
    global mat

    seeds = [(5, 5), (5, 4), (4, 4), (5, 6), (6, 5), (7, 1), (2, 3), (4, 5)]
    size = 100
    world = initialize_world__(size, seeds)
    mat = ax.matshow(world)

    ani = animation.FuncAnimation(
        fig, update, frames=100, interval=50, repeat=True)

    plt.show()


if __name__ == "__main__":
    main()
