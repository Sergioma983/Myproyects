import multiprocessing
import matplotlib.pyplot as plt
import ctypes
import time
import sys

tableData = []


def is_relative_prime(i, j):
    a = min(i, j)
    b = max(i, j)
    div = 2

    while (div <= a):
        if((a % div == 0) and (b % div == 0)):
            return False
        div += 1

    return True


def euclideanAlgorithmGCD(i, j):
    a = min(i, j)
    b = max(i, j)

    while(b != 0):
        t = b
        b = a % b
        a = t

    return a


def computeTableRelativelyPrime_Serial(rows, cols):

    global tableData
    tableData = [[0] * cols for _ in range(rows)]

    for ii in range(rows):
        for jj in range(cols):
            # a = min(ii, jj)
            # b = max(ii, jj)
            #
            # while( b!= 0 ):
            #     t = b
            #     b = a % b
            #     a = t
            #
            # tableData[ii][jj] = a == 1
            #tableData[ii][jj] = is_relative_prime(ii+2, jj+2)
            tableData[ii][jj] = euclideanAlgorithmGCD(ii+2, jj+2) == 1
    return


def computeRelativelyPrimeInRange(fromRow, sizeChunk, numCols):

    toRow = fromRow + sizeChunk

    localTableData = [[0] * numCols for _ in range(sizeChunk)]

    for ii in range(fromRow, toRow):
        for jj in range(numCols):
            #localTableData[idx-fromNumber][jj] = IsRelativelyPrime(ii+2, jj+2)
            localTableData[ii -
                           fromRow][jj] = euclideanAlgorithmGCD(ii+2, jj+2) == 1

    return [fromRow, sizeChunk, numCols, localTableData]


def relativePrimesInRange_sharedMemory(fromRow, sizeChunk, numCols, shared_array_numbers, shared_array_lengths):

    toRow = fromRow + sizeChunk

    localTableData = [[0] * numCols for _ in range(sizeChunk)]

    for ii in range(fromRow, toRow):
        for jj in range(numCols):
            #localTableData[idx-fromNumber][jj] = is_relative_prime(ii+2, jj+2)
            #localTableData[ii-fromRow][jj] = euclideanAlgorithmGCD(ii+2,jj+2) == 1
            shared_array_numbers[idx -
                                 fromNumber][jj] = is_relative_prime(ii+2, jj+2)
            shared_array_lengths[ii -
                                 fromRow][jj] = euclideanAlgorithmGCD(ii+2, jj+2) == 1

    return [fromRow, sizeChunk, numCols, shared_array_numbers]


def generate_table_primos_relativos_with_process_sharedMemory(rows, cols, numProcess):
    # setup shared memory
    shared_array_lengths = multiprocessing.Array(ctypes.c_double, rows)
    shared_array_numbers = multiprocessing.Array(ctypes.c_double, cols)

    # setup the subtask to assing
    numChunks = numProcess
    sizeChunk = int(rows / numProcess)

    fromLimits = []
    for ii in range(numChunks):
        # setup the chunk of data to work for each process
        fromLimit = ii*sizeChunk + 3
        fromLimits.append(fromLimit)

    jobs = []
    for limit in fromLimits:
        p = multiprocessing.Process(
            target=computeRelativelyPrimeInRange, args=(fromLimit, sizeChunk, cols))
        p.start()
        jobs.append(p)

    # waiting for all works is done

    for j in jobs:
        j.join()

    return[shared_array_numbers, shared_array_lengths]


"""
    Testing the code
"""


def main():
    print("".center(50, "-"))
    print("Shared Memory".center(45))
    print("".center(50, "-"))

    numRows = 1000
    numCols = 1000

    tic = time.time()
    computeTableRelativelyPrime_Serial(rows=numRows, cols=numCols)
    toc = time.time()
    T1 = toc - tic
    print(
        "Process Prime Serial took: {0}".format(toc-tic))
    print("".center(50, "-"))

    tic = time.time()
    [rows, cols] = generate_table_primos_relativos_with_process_sharedMemory(
        rows=numRows, cols=numCols, numProcess=multiprocessing.cpu_count())
    toc = time.time()
    print("Process time for Shared Memory: {0}".format(
        toc-tic))
    print("".center(50, "-"))


if __name__ == "__main__":
    main()
