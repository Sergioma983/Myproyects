CREATE DEFINER=`root`@`localhost` PROCEDURE `Actualizar_articulos`(cod_fac int)
BEGIN
	/*Comprobamos que el número de factura existe*/
	if exists (select Num_factura from factura where Num_factura = cod_fac) 
    then
		/*Si existe habilitamos la función actualizar 
        en workbench que por defecto viene desactivada*/
		SET SQL_SAFE_UPDATES = 0; 
        /*Se hace la actualizacion en el campo Total_Art
        con la suma de los articulos que nos regresa 
        nuestra funcion Retornar_Articulos*/
		UPDATE factura SET Total_Art = (Retornar_Articulos(cod_fac)) 
        where Num_factura = cod_fac;
	else 
		/*Si no existe aparece el siguiente mensaje*/
		select 'El numero de factura no existe' AS Resultado;
	end if;
END