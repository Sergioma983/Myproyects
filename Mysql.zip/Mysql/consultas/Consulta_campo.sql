CREATE DEFINER=`root`@`localhost` PROCEDURE `Consulta_campo`(letra char(10))
BEGIN
	IF EXISTS (SELECT * FROM information_schema.columns AS c1 WHERE c1.COLUMN_NAME like letra 
	AND c1.TABLE_NAME = 'razon_social') THEN
		select 'El campo existe' AS 'Resultado';
	else
		select 'El campo no existe' AS 'Resultado';
	END IF;
END