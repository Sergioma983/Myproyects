CREATE DEFINER=`root`@`localhost` FUNCTION `Retornar_Articulos`(num_fac int) 
RETURNS int(11)
BEGIN
	/*Se declara una variable donde se almacenara el total de los articulos 
   correspondiente al número de factura*/
	DECLARE total_articulos int;
    /*Se asigan el total de los articulos de la columna Cod_Articulo a la variable*/
	SET total_articulos = (select sum(Cantidad_Articulos) from detalle_factura 
    where Num_factura = num_fac); 
	/*La variable retorna el total de la suma de la columna Cod_Articulo*/
    RETURN total_articulos;
END