CREATE DEFINER=`root`@`localhost` PROCEDURE `Consulta_TBLProducto`()
BEGIN
	select * from producto;
END