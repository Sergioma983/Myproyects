-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema Documento_fiscal
-- -----------------------------------------------------
-- Base de datos de un caso de estudio de facturación

-- -----------------------------------------------------
-- Schema Documento_fiscal
--
-- Base de datos de un caso de estudio de facturación
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Documento_fiscal` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin ;
USE `Documento_fiscal` ;

-- -----------------------------------------------------
-- Table `Documento_fiscal`.`Razon_Social`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Documento_fiscal`.`Razon_Social` (
  `Id_Cliente` INT(15) NOT NULL COMMENT 'Campo que almacena el ID del cliente',
  `Razon_Social` VARCHAR(45) NULL COMMENT 'Campo que almacena el nombre del cliente',
  `Apellido_P` VARCHAR(45) NULL COMMENT 'Campo que almacena el Apellido Paterno del cliente',
  `Apellido_M` VARCHAR(45) NULL COMMENT 'Campo que almacena el Apellido Materno del cliente',
  `Fecha_nac` DATE NULL COMMENT 'Campo que almacena la fecha de nacimiento del cliente',
  `Sexo` VARCHAR(25) NULL COMMENT 'Campo que almacena el Sexo del cliente',
  `Telefono_cel` VARCHAR(20) NULL COMMENT 'Campo que almacena el telefono del cliente',
  `email` TEXT(50) NULL COMMENT 'Campo que almacena el email del cliente',
  PRIMARY KEY (`Id_Cliente`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Documento_fiscal`.`Pago`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Documento_fiscal`.`Pago` (
  `Id_pago` INT NOT NULL COMMENT 'Campo que almacena la clave primaria del metodo de pago',
  `Forma_pago` VARCHAR(45) NULL,
  `des_pago` VARCHAR(45) NULL COMMENT 'Campo que almacena la descripcion del metodo de pago',
  PRIMARY KEY (`Id_pago`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Documento_fiscal`.`Factura`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Documento_fiscal`.`Factura` (
  `Num_factura` INT NOT NULL COMMENT 'Campo que almacena el numero de factura',
  `Id_Cliente` INT(15) NULL COMMENT 'Clave foranea de la tabla Cliente',
  `Id_pago` INT NULL COMMENT 'Clave foranea de la tabla Pago',
  `Fecha_factura` DATETIME NULL COMMENT 'Campo que almacena la fecha y la hora de la factura ',
  `RFC` VARCHAR(45) NULL COMMENT 'Campo que almacena el RFC del cliente para la factura',
  `Regimen_Fis` VARCHAR(45) NULL,
  `Total_Art` INT NULL COMMENT 'Campo que almacena el total de articulos de la factura',
  `Sub_Total` DECIMAL(7,2) NULL COMMENT 'Campo que almacena el subtotal de la factura',
  `IVA` DECIMAL(7,2) NULL COMMENT 'Campo que almacena el porcentaje de iva de la factura',
  `Descuento` DECIMAL(7,2) NULL,
  `Total_Neto` DECIMAL(7,2) NULL COMMENT 'Campo que almacena el total neto a pagar de la factura',
  PRIMARY KEY (`Num_factura`),
  INDEX `FK_tablaCliente` (`Id_Cliente` ASC),
  INDEX `fk_tablaFactura` (`Id_pago` ASC),
  CONSTRAINT `FK_tablaCliente`
    FOREIGN KEY (`Id_Cliente`)
    REFERENCES `Documento_fiscal`.`Razon_Social` (`Id_Cliente`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Factura_Pago1`
    FOREIGN KEY (`Id_pago`)
    REFERENCES `Documento_fiscal`.`Pago` (`Id_pago`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Documento_fiscal`.`Categoria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Documento_fiscal`.`Categoria` (
  `Id_Categoria` INT NOT NULL COMMENT 'Campo que almacena el codigo de la categoria',
  `Descripcion_Productro` VARCHAR(45) NULL COMMENT 'Campo que almacena la descripcion de la categoria',
  PRIMARY KEY (`Id_Categoria`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Documento_fiscal`.`Producto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Documento_fiscal`.`Producto` (
  `Cod_Articulo` INT NOT NULL COMMENT 'Campo que almacena el codigo del articulo del producto',
  `Id_Categoria` INT NULL COMMENT 'Clave foranea de la tabla Categoria',
  `Nombre_Producto` VARCHAR(45) NULL COMMENT 'Campo que almacena el nombre del producto',
  `Precio` DECIMAL(7,2) NULL COMMENT 'Campo que almacena el precio del producto',
  `Existencias_Producto` VARCHAR(45) NULL COMMENT 'Campo que almacena el numero de existencias del producto',
  PRIMARY KEY (`Cod_Articulo`),
  INDEX `FK_tablaCategoria` (`Id_Categoria` ASC),
  CONSTRAINT `FK_tablaCategoria`
    FOREIGN KEY (`Id_Categoria`)
    REFERENCES `Documento_fiscal`.`Categoria` (`Id_Categoria`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Documento_fiscal`.`Detalle_Factura`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Documento_fiscal`.`Detalle_Factura` (
  `Cantidad_Articulos` INT NULL COMMENT 'Campo que almacena la cantidad de articulos en detalle de la factura',
  `Num_factura` INT NULL COMMENT 'Clave foranea de la tabla Factura',
  `Cod_Articulo` INT NULL COMMENT 'Clave foranea de la tabla Producto',
  `Importe` DECIMAL(7,2) NULL COMMENT 'Campo que almacena el importe en detalle de la factura',
  INDEX `fk_Detalle_Factura_Factura1_idx` (`Num_factura` ASC),
  INDEX `fk_Detalle_Factura_Producto1_idx` (`Cod_Articulo` ASC),
  CONSTRAINT `fk_Detalle_Factura_Factura1`
    FOREIGN KEY (`Num_factura`)
    REFERENCES `Documento_fiscal`.`Factura` (`Num_factura`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Detalle_Factura_Producto1`
    FOREIGN KEY (`Cod_Articulo`)
    REFERENCES `Documento_fiscal`.`Producto` (`Cod_Articulo`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
