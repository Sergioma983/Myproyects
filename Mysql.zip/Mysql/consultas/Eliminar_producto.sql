CREATE DEFINER=`root`@`localhost` PROCEDURE `Eliminar_producto`(factura_cliente int, producto_cod int, cantidad int)
BEGIN
	DECLARE existencia int;
	SET existencia = (select stock_funcion(producto_cod));
	SET sql_safe_updates=0;
    -- vereficamos si existe nuestra factura --
		if exists (select detalle_factura.ID_FACTURA,detalle_factura.ID_PROD from detalle_factura where detalle_factura.ID_FACTURA = factura_cliente 
        and detalle_factura.ID_PROD = producto_cod) then
				-- actualizamos tabla detalle_factura en el campo Cantidad_Articulos --
				UPDATE detalle_factura SET detalle_factura.Cantidad_Articulos = detalle_factura.Cantidad_Articulos - cantidad 
                WHERE detalle_factura.ID_PROD = producto_cod and
                detalle_factura.ID_FACTURA = factura_cliente;
                -- tambien actualizamos la tabla producto campo Existencia_Prod --
                UPDATE producto SET Existencias_Prod = existencia + cantidad WHERE producto.ID_PROD = producto_cod;
                -- MANDAMOS A LLAMAR TU FUNCION IMPORTE PARA QUE ACTUALICE EN LA TABLA FACTURA CAMPO IMPORTE AL MOMENTO DE LA ACTUALIZACION --
				call IMPORTE(factura_cliente);
                -- Este if es para eliminar un producto cuando este disminuya hasta llegar a 0 se eliminara de la tabla detalle factura en automatico --
                if (select detalle_factura.Cantidad_Articulos = 0 from detalle_factura where detalle_factura.ID_FACTURA = factura_cliente 
				and detalle_factura.ID_PROD = producto_cod) then
					delete from detalle_factura where detalle_factura.ID_FACTURA = factura_cliente 
                    and detalle_factura.ID_PROD = producto_cod = producto_cod;
				end if;
        else
			select 'El no de factura no existe';
		end if;
END