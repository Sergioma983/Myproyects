CREATE DEFINER=`root`@`localhost` PROCEDURE `Agregar_campo`()
BEGIN
	IF NOT EXISTS (SELECT * FROM information_schema.columns AS c1 WHERE c1.COLUMN_NAME = 'edad' 
		AND c1.TABLE_NAME = 'razon_social') THEN
		alter table razon_social add edad int(10) after Fecha_nac;
        Describe razon_social;
	else
		SET SQL_SAFE_UPDATES = 0; 
		UPDATE razon_social SET edad = (timestampdiff(YEAR,Fecha_nac,CURDATE()));
        SELECT * FROM razon_social;
	END IF;
END