use documento_fiscal;
call Generador_RFC(1747);
call Generador_RFC(1538);
SELECT * FROM detalle_factura;
SELECT * FROM factura;
call Agregar_carrito(1747,1313,1);
call Importe_subtotal(1538);
call Importe_subtotal(1747);
select retornar_subtotal(1747);
select Retornar_Articulos(1538);
Call Quitar_carrito(1747,1313,2);
select * from producto where Cod_Articulo = 1313;
update producto set Existencias_Producto = 10 where Cod_Articulo = 1313;

select prueba_RFC(1747);

select razon_social.razon_social,razon_social.Apellido_P,razon_social.Apellido_M,razon_social.email,
	razon_social.Id_Cliente, factura.Fecha_factura, factura.RFC, factura.Num_factura from razon_social,factura
    where razon_social.Id_Cliente=factura.Id_Cliente and razon_social.Id_Cliente=9817;

select Fecha_factura, Num_factura, RFC from factura where Id_Cliente=9817;

select * from pago;

call Forma_de_pago(1538,4);

