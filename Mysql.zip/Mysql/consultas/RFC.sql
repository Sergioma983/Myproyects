CREATE DEFINER=`root`@`localhost` FUNCTION `prueba_RFC`(num_fac int) RETURNS varchar(20) CHARSET utf8 COLLATE utf8_bin
BEGIN
	declare primera varchar(1);
    declare segunda varchar(1);
    declare completo varchar(2);
    SET segunda = (select upper (SUBSTRING(Apellido_P, 1,1))
		from razon_social, factura
		where Num_factura = num_fac and razon_social.Id_Cliente = factura.Id_Cliente);
        
    SET primera = (select upper (SUBSTRING(Apellido_P, 2,1))
		from razon_social, factura
		where Num_factura = num_fac and razon_social.Id_Cliente = factura.Id_Cliente);
        
	if primera = 'A' OR primera = 'E' OR primera = 'I' OR primera = 'O' OR primera = 'U' then
		set completo = concat(segunda,primera);
		return completo;
	else 
		set primera = (select upper (SUBSTRING(Apellido_P, 3,1))
		from razon_social, factura
		where Num_factura = num_fac and razon_social.Id_Cliente = factura.Id_Cliente);
        set completo = concat(segunda,primera);
        return completo;
	end if;
END