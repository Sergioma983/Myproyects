USE documento_fiscal;
insert into razon_social values();
select * from producto where Cod_Articulo = 1224;
select * from producto;
select * from detalle_factura order by Num_factura;
select * from factura;
select * from razon_social;
/*Generamos una nueva factura para el cliente 9817*/
Call Generar_numfactura(9817);
/*Una vez ya creado nuestra factura agregamos productos deseados*/
call Agregar_carrito(1850,1224,20);
call Quitar_carrito(1850,1224,20,2);
call Importe_subtotal(1850);



