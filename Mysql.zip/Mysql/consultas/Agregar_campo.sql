CREATE PROCEDURE `Agregar_campo` ()
BEGIN
	IF EXISTS (SELECT * FROM information_schema.columns AS c1 WHERE c1.COLUMN_NAME like letra 
		AND c1.TABLE_NAME = 'razon_social') THEN
		alter table razon_social add edad int(10) after Fecha_nac;
        Describe razon_social;
	else
		select 'El campo no existe' AS 'Resultado';
	END IF;
END
