use factura_fiscal;
/*Generamos una nueva factura al cliente*/
call Generar_Numero_Factura(666);
select * from productos;
/*Ingresamos un nuevo producto al carrito con los siguientes 
parametros (ID_FACTURA, CODIGO_PRODUCTO, CANTIDAD_DEL PRODUCTO)*/
call Agregar_producto(1542,107,2);
/*Vereficamos que el producto fue añadido*/
SELECT * FROM detallefact;
/*Nos falto un producto eran 3 en lugar de 2
vamos a actualizar el carrito con los mismos parametros*/
call actualizar_carrito(1542,107,1);
/*Vereficamos que el producto fue añadido*/
SELECT * FROM detallefact;
/*Vereficamos en el stock de productos el cambio*/
SELECT * FROM PRODUCTOS WHERE IdProducto = 501;
/*Hubo un error no son 3 productos los que necesitamos solo son 2
volvemos a actualizar el carrito con los mismos parametros*/
call Eliminar_producto(1542,107,1);
/*Vereficamos en el stock de productos el cambio*/
SELECT * FROM PRODUCTOS WHERE IdProducto = 501;
/*Vereficamos que el producto fue eliminado*/
SELECT * FROM detallefact;
/*Confirmamos cuanto es el total neto a pagar*/
SELECT * FROM factura;
/*Preguntamos cual es su metodo del pago
1-. Credito
2-. Debito*/
SELECT * FROM metodpago;
/*Confirmamos su metodo de pago con los parametros
(NUMERO_FACTURA Y OPCION ELEGIDA*/
call tipo_pago(1448,2);
/*Confirmamos el ID de nuestro metodo de pago*/
SELECT * FROM factura;
/*Verificamos cuantas facturas tiene el cliente 666*/
call consulta_facturas(666);