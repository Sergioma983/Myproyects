CREATE DEFINER=`root`@`localhost` PROCEDURE `Depositar`(dinero decimal(7,2),deposito int, pago int)
BEGIN
	declare saldo_actual decimal(7,2);
	if exists (select numero_cuenta from cuenta where numero_cuenta = deposito) then
			if exists (select numero_cuenta from cuenta where numero_cuenta = pago) then
				select cuenta.saldo into saldo_actual from cuenta where cuenta.numero_cuenta = deposito for update;
				select saldo_actual as 'resultado';
			end if;
	else
		select "El numero de cuenta no existe";
	end if;
END